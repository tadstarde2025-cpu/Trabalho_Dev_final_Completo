<?php
// capitulo.php — tela de jogo do capítulo
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

$cap = isset($_GET['cap']) ? (int)$_GET['cap'] : 1;
$modo = isset($_GET['modo']) ? $_GET['modo'] : 'campanha';
$liga_id = isset($_GET['liga_id']) ? (int)$_GET['liga_id'] : null;
$dataFile = __DIR__ . "/data/cap{$cap}.php";
if (!file_exists($dataFile)) {
  http_response_code(404);
  die("Capítulo {$cap} não encontrado.");
}
$CAP = require $dataFile;

// HP persistente
if (!isset($_SESSION['hp'])) {
  $_SESSION['hp'] = 100;
}
$startingHp = (int)$_SESSION['hp'];
if ($startingHp < 0)   $startingHp = 0;
if ($startingHp > 100) $startingHp = 100;

// Somatório global (tempo + combos + pontos)
if (!isset($_SESSION['total_ms']))      $_SESSION['total_ms'] = 0;
if (!isset($_SESSION['total_correct'])) $_SESSION['total_correct'] = 0;
if (!isset($_SESSION['total_points']))  $_SESSION['total_points'] = 0;

$totalMs      = (int)$_SESSION['total_ms'];
$totalCorrect = (int)$_SESSION['total_correct'];
$totalPoints  = (int)$_SESSION['total_points'];

function formatTime($ms) {
  $sec = floor($ms / 1000);
  $m = floor($sec / 60);
  $s = $sec % 60;
  return sprintf('%02d:%02d', $m, $s);
}

// Verificar se há mensagem de reset para mostrar
$reset_message = null;
if (isset($_SESSION['reset_message'])) {
    $reset_message = $_SESSION['reset_message'];
    unset($_SESSION['reset_message']); // Remove a mensagem da sessão após capturar
}

?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title><?= htmlspecialchars($CAP['title']) ?></title>
  <link rel="stylesheet" href="cap.css">
</head>
<body>
  <?php if ($reset_message): ?>
    <div id="resetMessage" style="position: fixed; top: 20px; right: 20px; background: #28a745; color: white; padding: 15px 20px; border-radius: 5px; z-index: 9999; box-shadow: 0 2px 10px rgba(0,0,0,0.2);">
      <?= htmlspecialchars($reset_message) ?>
      <button onclick="document.getElementById('resetMessage').style.display='none'" style="background: none; border: none; color: white; float: right; margin-left: 10px; cursor: pointer; font-weight: bold;">×</button>
    </div>
    <script>
      // Auto-hide message after 5 seconds
      setTimeout(function() {
        var msg = document.getElementById('resetMessage');
        if (msg) msg.style.display = 'none';
      }, 5000);
    </script>
  <?php endif; ?>
  
  <div id="game">
    <main class="play">
      <!-- ESQUERDA: AEDRIC -->
      <aside class="hero-panel">
        <div class="hero-image-wrap frame" id="heroFrame">
          <img id="heroImg" src="<?= htmlspecialchars($CAP['heroImage'] ?? 'img/aedric.png') ?>" alt="Aedric">
        </div>

        <div id="hero-hp-bar-container">
          <div id="hero-hp-bar"></div>
        </div>
        <div class="hero-hp-text">HP <span id="hpText"><?= $startingHp ?></span></div>

        <div class="timer">⏱ <span id="timer">00:00</span></div>
      </aside>

      <!-- CENTRO: VILÃO + INPUT -->
      <section class="scene">
        <div class="enemy-panel">
          <div class="enemy-image-wrap frame" id="enemyFrame">
            <img id="enemyImg" src="" alt="Vilão">
          </div>
          <div class="enemy-name" id="enemyName"></div>
          <div class="enemy-phrase" id="enemyPhrase"></div>
        </div>

        <div class="prompt-panel">
          <div class="prompt-instructions">Digite a palavra para derrotar o inimigo:</div>
          <div id="prompt" class="prompt">—</div>
          <input id="input" class="type-input" autocomplete="off" autocapitalize="off" spellcheck="false" />
          <div id="feedback" class="feedback"></div>

          <div class="death-actions">
            <button id="resetPhaseBtn" class="btn btn-small hidden">Reiniciar Capítulo</button>
            <button id="resetAllBtn" class="btn btn-small hidden">Resetar Tudo</button>
          </div>
        </div>
      </section>

      <!-- DIREITA: STATS + LIÇÕES + RECOMPENSA -->
      <aside class="right-panel">
        <div class="stats">
          <div>Combo: <span id="combo">0</span></div>
          <div>Runa: <span id="runa">—</span></div>
          
          <!-- Botões de navegação sempre visíveis -->
          <div style="margin-top: 1rem; text-align: center;">
            <a href="trabdev.php" class="btn btn-small" style="background: #6c757d; margin-bottom: 0.5rem; display: block;">🏠 Menu Principal</a>
            <button onclick="resetarJogo()" class="btn btn-small" style="background: #dc3545; display: block; width: 100%;">🔄 Resetar Jogo</button>
          </div>
        </div>

        <div class="rune-slot">
          <!-- Botão de coletar recompensa mais para cima -->
          <button id="collectBtn" class="btn hidden">Coletar Recompensa</button>

          <h3>Lições do Capítulo</h3>
          <ul id="lessons" class="lessons"></ul>

          <div id="rewardBox" class="reward hidden">
            <h3>Parabéns! Você ganhou a runa:</h3>
            <div class="reward-name" id="rewardName"></div>
            <div class="reward-image">
              <img id="rewardImg" src="" alt="Runa">
            </div>
            <pre id="rewardDesc" class="reward-desc"></pre>

            <div class="reward-time">
              Tempo deste capítulo: <span id="chapterTime">00:00</span><br>
              Multiplicador deste capítulo: <span id="chapterMultiplier">x1.0</span><br>
              Pontos deste capítulo: <span id="chapterPoints">0</span><br>
              Tempo total: <span id="totalTime"><?= formatTime($totalMs) ?></span><br>
              Combos totais: <span id="totalCombos"><?= $totalCorrect ?></span><br>
              Pontos totais: <span id="totalPoints"><?= $totalPoints ?></span>
            </div>

            <div class="reward-actions">
              <div style="margin-bottom: 1rem;">
                <a href="historico.php" style="color: #FFD700; text-decoration: none; margin-right: 1rem;">📊 Ver Histórico</a>
                <a href="rankings.php" style="color: #FFD700; text-decoration: none;">🏆 Rankings</a>
              </div>
              <?php if (!empty($CAP['next']) && $CAP['next'] !== null && is_numeric($CAP['next']) && $cap < 6): ?>
                <a id="nextChapter" class="btn" href="cap_intro.php?cap=<?= (int)$CAP['next'] ?><?= $modo == 'liga' ? '&modo=liga&liga_id=' . $liga_id : '' ?>">
                  Próximo Capítulo
                </a>
              <?php elseif ($cap >= 6): ?>
                <?php if ($modo == 'liga' && $liga_id): ?>
                  <a class="btn" href="liga_ranking.php?id=<?= $liga_id ?>">🏆 Ver Ranking da Liga</a>
                <?php endif; ?>
                <a class="btn" href="trabdev.php">🏠 Voltar ao Menu</a>
                <a class="btn" href="cap_intro.php?cap=1<?= $modo == 'liga' ? '&modo=liga&liga_id=' . $liga_id : '' ?>" style="margin-top: 0.5rem;">🔄 Recomeçar Jogo</a>
              <?php else: ?>
                <a class="btn" href="trabdev.php">🏠 Voltar ao Menu</a>
                <a class="btn" href="cap_intro.php?cap=1<?= $modo == 'liga' ? '&modo=liga&liga_id=' . $liga_id : '' ?>" style="margin-top: 0.5rem;">🔄 Recomeçar Jogo</a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </aside>
    </main>
  </div>

  <script>
    window.START_HP       = <?= (int)$startingHp ?>;
    window.CAP_DATA       = <?= json_encode($CAP, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
    window.CAP_NUM        = <?= (int)$cap ?>;
    window.TOTAL_MS       = <?= (int)$totalMs ?>;
    window.TOTAL_CORRECT  = <?= (int)$totalCorrect ?>;
    window.TOTAL_POINTS   = <?= (int)$totalPoints ?>;
    window.MODO           = '<?= $modo ?>';
    window.LIGA_ID        = <?= $liga_id ? (int)$liga_id : 'null' ?>;
    
    // Função para resetar o jogo
    function resetarJogo() {
        if (confirm('Tem certeza que deseja resetar todo o progresso? Isso apagará seu progresso atual.')) {
            var params = 'mode=all&cap=1';
            if (window.MODO && window.MODO !== 'campanha') {
                params += '&modo=' + window.MODO;
            }
            if (window.LIGA_ID && window.LIGA_ID !== null) {
                params += '&liga_id=' + window.LIGA_ID;
            }
            window.location.href = 'reset_state.php?' + params;
        }
    }
  </script>
  <script src="cap.js"></script>
</body>
</html>
