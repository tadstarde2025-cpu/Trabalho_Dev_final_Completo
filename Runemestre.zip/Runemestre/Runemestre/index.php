<?php
// index.php - Página inicial que redireciona para trabdev.php
header("Location: trabdev.php");
exit();
?>