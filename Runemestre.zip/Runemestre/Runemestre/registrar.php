<?php
// registrar.php - Processar registro de usuário
session_start();
require_once 'config.php';

if ($pdo === null) {
    header("Location: register.php?erro=conexao_db");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    
    // Validações básicas
    if (empty($nome) || empty($email) || empty($senha) || empty($confirmar_senha)) {
        header("Location: register.php?erro=campos_obrigatorios");
        exit();
    }
    
    if ($senha !== $confirmar_senha) {
        header("Location: register.php?erro=senhas_diferentes");
        exit();
    }
    
    if (strlen($senha) < 6) {
        header("Location: register.php?erro=senha_fraca");
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: register.php?erro=email_invalido");
        exit();
    }
    
    try {
        // Verificar se email já existe
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            header("Location: register.php?erro=email_existe");
            exit();
        }
        
        // Inserir novo usuário
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
        $stmt->execute([$nome, $email, $senha_hash]);
        
        // Buscar o ID do usuário recém-criado
        $usuario_id = $pdo->lastInsertId();
        
        // Fazer login automático
        $_SESSION['usuario_id'] = $usuario_id;
        $_SESSION['usuario_nome'] = $nome;
        $_SESSION['usuario_email'] = $email;
        
        // Redirecionar para página principal
        header("Location: trabdev.php");
        exit();
        
    } catch(PDOException $e) {
        header("Location: register.php?erro=erro_servidor");
        exit();
    }
} else {
    header("Location: register.php");
    exit();
}
?>