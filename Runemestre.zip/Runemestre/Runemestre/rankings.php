<?php
// rankings.php - Página dos rankings (apenas campanha)
session_start();
require_once 'config.php';

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

// Buscar ranking geral (apenas campanha)
try {
    $stmt = $pdo->prepare("SELECT u.nome, u.pontuacao 
                           FROM usuarios u 
                           WHERE u.pontuacao > 0
                           ORDER BY u.pontuacao ASC 
                           LIMIT 100");
    $stmt->execute();
    $ranking_geral = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $ranking_geral = [];
}

// Buscar estatísticas gerais
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total_jogadores, 
                                MAX(pontuacao) as maior_pontuacao, 
                                AVG(pontuacao) as media_pontuacao 
                         FROM usuarios WHERE pontuacao > 0");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $stats = ['total_jogadores' => 0, 'maior_pontuacao' => 0, 'media_pontuacao' => 0];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Rankings - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }
        .stat-card {
            background: rgba(0,0,0,0.7);
            padding: 1.5rem;
            border-radius: 10px;
            border: 2px solid #ffd700;
            text-align: center;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #ffd700;
            display: block;
            margin: 0.5rem 0;
        }
        .ranking-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }
        .ranking-table th,
        .ranking-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        .ranking-table th {
            background: rgba(255,215,0,0.2);
            font-weight: bold;
            color: #ffd700;
        }
        .ranking-table tr:hover {
            background: rgba(255,215,0,0.1);
        }
        .position {
            font-weight: bold;
            text-align: center;
            width: 80px;
        }
        .position.first { color: #ffd700; }
        .position.second { color: #c0c0c0; }
        .position.third { color: #cd7f32; }
    </style>
</head>
<body class="page-rankings">
    <header>
        <h1>🏆 Rankings - The Legend of Typing</h1>
        <nav>
            <ul>
                <li><a href="trabdev.php">🏠 Início</a></li>
                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <li><a href="cap_intro.php?cap=1">🎮 Campanha</a></li>
                    <li><a href="historico.php">📊 Histórico</a></li>
                    <li><a href="logout.php">🚪 Sair</a></li>
                <?php else: ?>
                    <li><a href="login.php">🔑 Entrar</a></li>
                    <li><a href="register.php">📝 Registrar</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>📈 Estatísticas Gerais</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>👥 Total de Runemestres</h3>
                    <span class="stat-value"><?= number_format($stats['total_jogadores']) ?></span>
                </div>
                <div class="stat-card">
                    <h3>🏆 Melhor Pontuação</h3>
                    <span class="stat-value"><?= number_format($stats['maior_pontuacao']) ?></span>
                </div>
                <div class="stat-card">
                    <h3>📊 Pontuação Média</h3>
                    <span class="stat-value"><?= number_format($stats['media_pontuacao'], 0) ?></span>
                </div>
            </div>
        </section>

        <section>
            <h2>🏅 Ranking Geral da Campanha</h2>
            <p>Os melhores Runemestres de todos os tempos</p>
            
            <?php if (empty($ranking_geral)): ?>
                <p>Nenhum jogador com pontuação ainda. Seja o primeiro!</p>
            <?php else: ?>
                <table class="ranking-table">
                    <thead>
                        <tr>
                            <th class="position">Posição</th>
                            <th>Nome do Runemestre</th>
                            <th>Pontuação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ranking_geral as $i => $jogador): 
                            $posicao = $i + 1;
                            $css_class = '';
                            if ($posicao == 1) $css_class = 'first';
                            elseif ($posicao == 2) $css_class = 'second';
                            elseif ($posicao == 3) $css_class = 'third';
                        ?>
                            <tr>
                                <td class="position <?= $css_class ?>">
                                    <?php if ($posicao == 1): ?>
                                        🥇 <?= $posicao ?>º
                                    <?php elseif ($posicao == 2): ?>
                                        🥈 <?= $posicao ?>º
                                    <?php elseif ($posicao == 3): ?>
                                        🥉 <?= $posicao ?>º
                                    <?php else: ?>
                                        <?= $posicao ?>º
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($jogador['nome']) ?></td>
                                <td><?= number_format($jogador['pontuacao']) ?> pontos</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>

        <section>
            <h2>ℹ️ Como Funciona a Pontuação</h2>
            <ul>
                <li><strong>Sistema baseado em tempo:</strong> Quanto menos tempo, melhor a pontuação</li>
                <li><strong>Multiplicadores por capítulo:</strong> Capítulos mais avançados valem mais pontos</li>
                <li><strong>Apenas o melhor:</strong> Só sua melhor pontuação conta para o ranking</li>
                <li><strong>Campanha completa:</strong> Precisa completar todos os 6 capítulos para pontuar</li>
            </ul>
        </section>
    </main>
</body>
</html>