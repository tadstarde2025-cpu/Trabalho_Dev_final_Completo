<?php
// cap_intro.php
session_start();

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

$cap = isset($_GET['cap']) ? (int)$_GET['cap'] : 1;
$modo = isset($_GET['modo']) ? $_GET['modo'] : 'campanha';
$liga_id = isset($_GET['liga_id']) ? (int)$_GET['liga_id'] : null;

// Se for modo liga, verificar se usuário está na liga
$liga_nome = '';
if ($modo == 'liga' && $liga_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT l.nome 
            FROM ligas l 
            JOIN liga_participantes lp ON l.id = lp.liga_id 
            WHERE l.id = ? AND lp.usuario_id = ?
        ");
        $stmt->execute([$liga_id, $_SESSION['usuario_id']]);
        $liga = $stmt->fetch();
        
        if (!$liga) {
            // Usuário não está na liga, redirecionar
            header("Location: ligas.php");
            exit();
        }
        
        $liga_nome = $liga['nome'];
    } catch(PDOException $e) {
        header("Location: ligas.php");
        exit();
    }
}

$dataFile = __DIR__ . "/data/cap{$cap}.php";
if (!file_exists($dataFile)) {
  http_response_code(404);
  die("Capítulo {$cap} não encontrado.");
}
$CAP = require $dataFile;

// Totais acumulados (para mostrar se quiser)
if (!isset($_SESSION['total_ms']))      $_SESSION['total_ms'] = 0;
if (!isset($_SESSION['total_correct'])) $_SESSION['total_correct'] = 0;

$totalMs      = (int)$_SESSION['total_ms'];
$totalCorrect = (int)$_SESSION['total_correct'];

function formatTime($ms) {
  $sec = floor($ms / 1000);
  $m = floor($sec / 60);
  $s = $sec % 60;
  return sprintf('%02d:%02d', $m, $s);
}

// Verificar se há mensagem de reset para mostrar
$reset_message = null;
if (isset($_SESSION['reset_message'])) {
    $reset_message = $_SESSION['reset_message'];
    unset($_SESSION['reset_message']); // Remove a mensagem da sessão após capturar
}

?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title><?= htmlspecialchars($CAP['title']) ?> — Intro</title>
  <link rel="stylesheet" href="cap.css">
</head>
<body>
  <?php if ($reset_message): ?>
    <div id="resetMessage" style="position: fixed; top: 20px; right: 20px; background: #28a745; color: white; padding: 15px 20px; border-radius: 5px; z-index: 9999; box-shadow: 0 2px 10px rgba(0,0,0,0.2);">
      <?= htmlspecialchars($reset_message) ?>
      <button onclick="document.getElementById('resetMessage').style.display='none'" style="background: none; border: none; color: white; float: right; margin-left: 10px; cursor: pointer; font-weight: bold;">×</button>
    </div>
    <script>
      // Auto-hide message after 5 seconds
      setTimeout(function() {
        var msg = document.getElementById('resetMessage');
        if (msg) msg.style.display = 'none';
      }, 5000);
    </script>
  <?php endif; ?>
  
  <div id="game">
    <section class="intro">
      <div class="intro-wrap">
        <div class="intro-image">
          <?php if (!empty($CAP['introImage'])): ?>
            <img src="<?= htmlspecialchars($CAP['introImage']) ?>" alt="Capítulo">
          <?php else: ?>
            <div class="intro-placeholder">Capítulo <?= (int)$cap ?></div>
          <?php endif; ?>
        </div>

        <div class="intro-text">
          <h1><?= htmlspecialchars($CAP['title']) ?></h1>
          <p>Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']) ?></strong>!</p>
          
          <?php if ($modo == 'liga' && $liga_nome): ?>
            <div style="background: rgba(255,215,0,0.2); border: 2px solid #ffd700; border-radius: 10px; padding: 1rem; margin: 1rem 0;">
              <h3>🏆 Modo Liga</h3>
              <p><strong>Liga:</strong> <?= htmlspecialchars($liga_nome) ?></p>
              <p><em>Sua pontuação será registrada no ranking da liga!</em></p>
            </div>
          <?php endif; ?>
          
          <p><?= nl2br(htmlspecialchars($CAP['introText'])) ?></p>

          <a href="capitulo.php?cap=<?= $cap ?><?= $modo == 'liga' ? '&modo=liga&liga_id=' . $liga_id : '' ?>" 
             class="btn" 
             onclick="window.location.href=this.href; return false;"
             style="display: inline-block; padding: 1rem 2rem; background: #007bff; color: white; text-decoration: none; border-radius: 5px; cursor: pointer; z-index: 1000; position: relative; margin: 1rem 0;">
            ▶️ Iniciar Capítulo <?= (int)$cap ?>
          </a>
          
          <!-- Botão alternativo para debug -->
          <div style="margin-top: 1rem;">
            <button onclick="irParaCapitulo()" style="padding: 0.8rem 1.5rem; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">
              🚀 Iniciar Jogo (Alternativo)
            </button>
          </div>

          <div class="intro-summary">
            <small>
              Tempo total: <?= formatTime($totalMs) ?><br>
              Combos totais: <?= $totalCorrect ?>
            </small>
            <br>
            <div style="margin-top: 1rem;">
              <a href="trabdev.php" style="color: #28a745; margin-right: 1rem;">🏠 Menu Principal</a>
              <a href="reset_state.php?mode=all&cap=1<?= $modo == 'liga' ? '&modo=liga&liga_id=' . $liga_id : '' ?>" onclick="return confirm('Resetar todo o progresso?')" style="color: #dc3545;">🔄 Resetar Jogo</a>
            </div>
            <br>
            <a href="logout.php" style="color: #ff6b6b; font-size: 12px;">Sair</a>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    function irParaCapitulo() {
      const cap = <?= (int)$cap ?>;
      const modo = '<?= $modo ?>';
      const ligaId = <?= $liga_id ? (int)$liga_id : 'null' ?>;
      
      let url = 'capitulo.php?cap=' + cap;
      if (modo === 'liga' && ligaId) {
        url += '&modo=liga&liga_id=' + ligaId;
      }
      window.location.href = url;
    }
  </script>
</body>
</html>
