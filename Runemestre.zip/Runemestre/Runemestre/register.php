<?php
// register.php - Página de registro
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Registrar - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body class="page-register">
    <header>
        <div class="header-inner">
            <img src="logodosite.jpg" alt="Símbolo The Legend of Typing" class="lot-logo">
            <div class="header-text">
                <h1>The Legend of Typing</h1>
                <p>Forjar um Novo Runemestre</p>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="login.php">Entrar</a></li>
                <li><a href="register.php">Registrar</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Criar Conta</h2>
            <p>
                Preencha os campos abaixo para gravar seu nome no grimório dos Runemestres
                e iniciar sua jornada contra Typoros.
            </p>

            <div id="errorMessage" style="display: none; background: rgba(220, 53, 69, 0.8); color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 2px solid #dc3545; text-align: center;">
                <span id="errorText"></span>
            </div>

            <form method="post" action="registrar.php">
                <div>
                    <label for="nome">Nome do Runemestre</label>
                    <input type="text" id="nome" name="nome" required>
                </div>

                <div>
                    <label for="email">Email (Orbe de Contato)</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div>
                    <label for="senha">Senha Rúnica</label>
                    <input type="password" id="senha" name="senha" minlength="6" required>
                </div>

                <div>
                    <label for="confirmar_senha">Confirmar Senha Rúnica</label>
                    <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6" required>
                </div>

                <div>
                    <button type="submit">Registrar</button>
                </div>
            </form>

            <p>
                Já fez seu pacto com as Runas?
                <a href="login.php">Acessar o Portão</a>
            </p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 The Legend of Typing</p>
    </footer>

    <script>
        // Verificar se há erro na URL
        const urlParams = new URLSearchParams(window.location.search);
        const erro = urlParams.get('erro');
        
        if (erro) {
            const errorDiv = document.getElementById('errorMessage');
            const errorText = document.getElementById('errorText');
            
            let mensagem = '';
            switch(erro) {
                case 'campos_obrigatorios':
                    mensagem = 'Todos os campos são obrigatórios para selar o pacto rúnico.';
                    break;
                case 'senhas_diferentes':
                    mensagem = 'As senhas rúnicas não coincidem. Verifique novamente.';
                    break;
                case 'senha_fraca':
                    mensagem = 'A senha rúnica deve ter pelo menos 6 caracteres.';
                    break;
                case 'email_invalido':
                    mensagem = 'O formato do email (Orbe de Contato) é inválido.';
                    break;
                case 'email_existe':
                    mensagem = 'Este email já está registrado no grimório dos Runemestres.';
                    break;
                case 'erro_servidor':
                    mensagem = 'Erro no servidor. Tente novamente mais tarde.';
                    break;
                default:
                    mensagem = 'Erro desconhecido. Tente novamente.';
            }
            
            errorText.textContent = mensagem;
            errorDiv.style.display = 'block';
            
            // Remover o erro da URL após mostrar
            const newUrl = window.location.pathname;
            window.history.replaceState({}, document.title, newUrl);
        }
    </script>
</body>
</html>