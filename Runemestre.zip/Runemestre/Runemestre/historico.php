<?php
// historico.php - Página do histórico de partidas do usuário
session_start();
require_once 'config.php';

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

// Buscar dados do usuário
try {
    $stmt = $pdo->prepare("SELECT u.nome, u.pontuacao 
                           FROM usuarios u 
                           WHERE u.id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $usuario = null;
}

// Buscar histórico de partidas do usuário
try {
    $stmt = $pdo->prepare("SELECT capitulo, tempo_ms, acertos, pontos_ganhos, data_partida 
                           FROM historico_partidas 
                           WHERE usuario_id = ? 
                           ORDER BY data_partida DESC 
                           LIMIT 50");
    $stmt->execute([$_SESSION['usuario_id']]);
    $partidas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $partidas = [];
}

// Calcular estatísticas
$total_partidas = count($partidas);
$total_acertos = array_sum(array_column($partidas, 'acertos'));
$tempo_total_ms = array_sum(array_column($partidas, 'tempo_ms'));
$tempo_medio_s = $total_partidas > 0 ? round($tempo_total_ms / ($total_partidas * 1000), 2) : 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Histórico de Partidas - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        .stat-card {
            background: rgba(0,0,0,0.7);
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            border: 2px solid #444;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #FFD700;
        }
        .partidas-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 2rem;
            background: rgba(0,0,0,0.8);
        }
        .partidas-table th,
        .partidas-table td {
            padding: 0.8rem;
            border: 1px solid #444;
            text-align: center;
        }
        .partidas-table th {
            background: #333;
            color: #FFD700;
        }
        .partidas-table tr:nth-child(even) {
            background: rgba(255,255,255,0.05);
        }
        .nav-buttons {
            margin: 2rem 0;
            text-align: center;
        }
        .nav-buttons a {
            display: inline-block;
            margin: 0 0.5rem;
            padding: 0.8rem 1.5rem;
            background: #444;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-buttons a:hover {
            background: #666;
        }
    </style>
</head>
<body class="page-home">
    <header>
        <div class="header-inner">
            <img src="logodosite.jpg" alt="Símbolo The Legend of Typing" class="lot-logo">
            <div class="header-text">
                <h1>The Legend of Typing</h1>
                <p>Histórico de Partidas</p>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="capitulo.php">Campanha</a></li>

                <li><a href="rankings.php">Rankings</a></li>
                <li><a href="historico.php">Meu Histórico</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Perfil do Runemestre: <?= htmlspecialchars($usuario['nome'] ?? 'Desconhecido') ?></h2>
            
            <?php if ($usuario): ?>

                <p>Pontuação Total: <strong><?= number_format($usuario['pontuacao']) ?></strong> pontos</p>
            <?php endif; ?>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_partidas ?></div>
                    <div>Partidas Jogadas</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_acertos) ?></div>
                    <div>Total de Acertos</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $tempo_medio_s ?>s</div>
                    <div>Tempo Médio por Partida</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($usuario['pontuacao'] ?? 0) ?></div>
                    <div>Pontos Totais</div>
                </div>
            </div>
        </section>

        <section>
            <h2>Histórico das Últimas 50 Partidas</h2>
            
            <?php if (empty($partidas)): ?>
                <p>Nenhuma partida encontrada. <a href="capitulo.php">Comece a jogar!</a></p>
            <?php else: ?>
                <table class="partidas-table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Capítulo</th>
                            <th>Tempo</th>
                            <th>Acertos</th>
                            <th>Pontos Ganhos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($partidas as $partida): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($partida['data_partida'])) ?></td>
                                <td>Capítulo <?= $partida['capitulo'] ?></td>
                                <td><?= number_format($partida['tempo_ms'] / 1000, 2) ?>s</td>
                                <td><?= $partida['acertos'] ?></td>
                                <td><?= number_format($partida['pontos_ganhos']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>

        <div class="nav-buttons">
            <a href="capitulo.php">Jogar Novamente</a>
            <a href="rankings.php">Ver Rankings</a>
            <a href="trabdev.php">Página Inicial</a>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 The Legend of Typing</p>
    </footer>
</body>
</html>