<?php
// config.php - Configuração do banco de dados
$host = 'localhost';
$port = '3307';
$dbname = 'runemestre_db';
$username = 'root';

// Configurações comuns do XAMPP
$passwords = ['', 'root', '123456'];
$pdo = null;
$working_password = '';

// Testar diferentes senhas
foreach ($passwords as $test_password) {
    try {
        $test_pdo = new PDO("mysql:host=$host;port=$port;charset=utf8", $username, $test_password);
        $test_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Tentar criar o banco se não existir
        $test_pdo->exec("CREATE DATABASE IF NOT EXISTS $dbname");
        
        // Tentar conectar ao banco específico
        $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8", $username, $test_password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $working_password = $test_password;
        break;
        
    } catch(PDOException $e) {
        continue; // Tenta próxima senha
    }
}

if ($pdo === null) {
    die("Erro: Não foi possível conectar ao MySQL. Certifique-se de que:<br>
         1. O XAMPP está rodando<br>
         2. O MySQL está ativo<br>
         3. A senha do MySQL está correta<br><br>
         Senhas testadas: sem senha, 'root', '123456'<br>
         Se sua senha for diferente, edite o arquivo config.php");
}
?>