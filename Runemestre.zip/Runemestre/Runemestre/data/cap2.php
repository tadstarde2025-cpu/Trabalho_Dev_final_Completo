<?php
return [
  'title'      => 'Capítulo II — A Forja das Palavras',
  'introImage' => 'img/Cap2/vulcao.jpeg',
  'introText' => "Nas Montanhas da Forja, cada erro vira brasa e cada acerto, aço temperado. Dominar o verbo é temperar o próprio espírito.",
  'theme' => ['primary' => '#7a0f0f', 'accent' => '#ff9b2f'],
  'next'  => 3,
  'heroImage' => 'img/aedric.png',

  'villains' => [
    ['key'=>'chama','name'=>'Ignar — O Gárgula Flamejante Alfa','img'=>'img/Cap2/Cap2-1.jpeg','phrase'=>'Palavras curtas em altíssima velocidade.','lessonLong'=>'O fogo é rápido, mas o espírito deve ser firme.','lessonShort'=>'Firmeza vence a pressa.'],
    ['key'=>'centelha','name'=>'Vuldros — A Centelha Fugitiva','img'=>'img/Cap2/Cap2-2.jpeg','phrase'=>'Letras piscam e mudam de posição.','lessonLong'=>'O impulso cega o raciocínio.','lessonShort'=>'Respire antes de agir.'],
    ['key'=>'resistência','name'=>'Thernox — O Elemental de Cinza','img'=>'img/Cap2/Cap2-3.jpeg','phrase'=>'Palavras longas com letras duplicadas.','lessonLong'=>'A força vem da observação, não da pressa.','lessonShort'=>'Observe, então golpeie.'],
    ['key'=>'visão','name'=>'Cendrah — A Dama de Fumaça','img'=>'img/Cap2/Cap2-4.jpeg','phrase'=>'Oculta parcialmente as palavras.','lessonLong'=>'Mesmo nas cinzas, há estrutura.','lessonShort'=>'Veja através da névoa.'],
    ['key'=>'disciplina','name'=>'Molthur — O Runífero Fundido','img'=>'img/Cap2/Cap2-5.jpeg','phrase'=>'Pares certo/errado alternam rapidamente.','lessonLong'=>'Dominar o fogo é escolher o certo no caos.','lessonShort'=>'Escolha com calma.'],
    ['key'=>'forjar','name'=>'Brontash — O Martelo Errante','img'=>'img/Cap2/Cap2-6.jpeg','phrase'=>'Cada erro soa como golpe e reduz HP.','lessonLong'=>'O domínio vem da repetição deliberada.','lessonShort'=>'Repita para lapidar.'],
    ['key'=>'inteiro','name'=>'Reddun — O Espírito do Ferro Partilhado','img'=>'img/Cap2/Cap2-7.jpeg','phrase'=>'Divide palavras ao meio.','lessonLong'=>'Reunir o que se parte é restaurar o sentido.','lessonShort'=>'Recompõe o todo.'],
    ['key'=>'controle','name'=>'Pyrralis — A Chama Dourada','img'=>'img/Cap2/Cap2-8.jpeg','phrase'=>'Velocidade aumenta progressivamente.','lessonLong'=>'O fogo obedece a quem não teme queimá-lo.','lessonShort'=>'Controle sobre ímpeto.'],
    ['key'=>'ritmo','name'=>'Ferrun — O Guardião das Brasas Mortas','img'=>'img/Cap2/Cap2-9.jpeg','phrase'=>'Alterna fácil e extremamente complexo.','lessonLong'=>'Mesmo o metal precisa respirar.','lessonShort'=>'Ritmo é respiração.'],
    ['key'=>'temperar','name'=>'Gor’mak — O Ferreiro das Runas (Mini-Boss)','img'=>'img/Cap2/Cap2-10.jpeg','phrase'=>'Golpeia palavras contaminadas; salve as puras.','lessonLong'=>'A raiva é ferramenta; quem a teme, se queima.','lessonShort'=>'Tempere a força.'],
  ],

  'reward' => [
    'name'=>'Runo da Força Interior',
    'image'=>'img/Cap2/Cap2-runa.jpeg',
    'desc'=>"• Aumenta o multiplicador de combos.\n• Diminui o tempo entre acertos.\n• Desbloqueia o modo “Fornalha Viva”."
  ],

  'customCss' => '
    .scene{ background-image: radial-gradient(600px 320px at 70% -10%, rgba(255,155,47,.12), transparent 60%),
                               radial-gradient(800px 520px at 10% 120%, rgba(122,15,15,.20), transparent 60%); }
  ',
];
