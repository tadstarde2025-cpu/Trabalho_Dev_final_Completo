<?php
return [
  'title'      => 'Capítulo V — O Labirinto dos Espelhos',
  'introImage' => 'img/Cap5/espelho.jpeg',
  'introText'  => "Quando o verbo se vê a si mesmo, o erro vira ilusão. Aedric enfrenta as formas de sua própria dúvida.",
  'theme' => ['primary' => '#2b2e4a', 'accent' => '#e4d66a'],
  'next'  => 6,
  'heroImage' => 'img/aedric.png',

  'villains' => [
    ['key'=>'veracidade','name'=>'Mirael — O Reflexo Corrompido Alfa','img'=>'img/Cap5/Cap5-1.jpeg','phrase'=>'Cópia de Aedric com letras trocadas.','lessonLong'=>'A semelhança é máscara da falsidade.','lessonShort'=>'Vá além do reflexo.'],
    ['key'=>'fé','name'=>'Nythra — A Voz da Dúvida','img'=>'img/Cap5/Cap5-2.jpeg','phrase'=>'Sussurra negações; enfraquece foco.','lessonLong'=>'A dúvida ecoa a coragem adormecida.','lessonShort'=>'Fé na intenção.'],
    ['key'=>'silêncio','name'=>'Echoth — O Eco da Autocrítica','img'=>'img/Cap5/Cap5-3.jpeg','phrase'=>'Duplica erros em vozes de zombaria.','lessonLong'=>'A crítica perde força quando não é ouvida.','lessonShort'=>'Silencie o algoz.'],
    ['key'=>'clareza','name'=>'Lumeris — A Runa Ilusória','img'=>'img/Cap5/Cap5-4.jpeg','phrase'=>'Texto “certo” com erros ocultos (dr4gon).','lessonLong'=>'O engano mais perigoso parece correto.','lessonShort'=>'Veja de verdade.'],
    ['key'=>'agora','name'=>'Verrin — O Guardião dos Caminhos Repetidos','img'=>'img/Cap5/Cap5-5.jpeg','phrase'=>'Repete caminhos para confundir ordem.','lessonLong'=>'O passado é um espelho que atrasa.','lessonShort'=>'Foque no agora.'],
    ['key'=>'inteireza','name'=>'Nhalora — A Dama do Espelho Estilhaçado','img'=>'img/Cap5/Cap5-6.jpeg','phrase'=>'Quebra palavras em fragmentos.','lessonLong'=>'Quebrar não é perder — é compreender.','lessonShort'=>'Una as partes.'],
    ['key'=>'originalidade','name'=>'Veyth — A Sombra Anônima','img'=>'img/Cap5/Cap5-7.jpeg','phrase'=>'Imita sua digitação com erros propositais.','lessonLong'=>'O eu verdadeiro não compete com a sombra.','lessonShort'=>'Seja você.'],
    ['key'=>'propósito','name'=>'Kareon — O Arquiteto da Mentira','img'=>'img/Cap5/Cap5-8.jpeg','phrase'=>'Frases perfeitas, porém vazias.','lessonLong'=>'A forma sem significado é eco.','lessonShort'=>'Busque sentido.'],
    ['key'=>'percepção','name'=>'Lunara — Guardiã das Runas Invertidas','img'=>'img/Cap5/Cap5-9.jpeg','phrase'=>'Inverte palavras inteiras espelhando-as.','lessonLong'=>'A mente apressada toma erro por verdade.','lessonShort'=>'Observe devagar.'],
    ['key'=>'aceitação','name'=>'Nythera — A Tecepalavras (Mini-Boss)','img'=>'img/Cap5/Cap5-10.jpeg','phrase'=>'Cada erro dobra as ilusões na tela.','lessonLong'=>'A perfeição é prisão de espelhos.','lessonShort'=>'Aceite para vencer.'],
  ],

  'reward' => [
    'name'=>'Runo da Verdade Interior (Elyon)',
    'image'=>'img/Cap5/Cap5-runa.jpeg',
    'desc'=>"• Aumenta dano (multiplicador permanente).\n• Amplifica bônus de combos longos.\n• Desbloqueia “Verdade Desperta”."
  ],
];
