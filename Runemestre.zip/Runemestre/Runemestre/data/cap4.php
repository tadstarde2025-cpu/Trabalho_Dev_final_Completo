<?php
return [
  'title'      => 'Capítulo IV — O Eco das Chamas',
  'introImage' => 'img/Cap4/fogo.jpeg',
  'introText'  => "Nas câmaras do vulcão, o som encontra sua própria sombra. Ouça-se para extinguir o eco.",
  'theme' => ['primary' => '#5e1b1b', 'accent' => '#ffb86b'],
  'next'  => 5,
  'heroImage' => 'img/aedric.png',

  'villains' => [
    ['key'=>'espelho','name'=>'Volthar — A Salamandra do Som Alfa','img'=>'img/Cap4/Cap4-1.jpeg','phrase'=>'Palavras invertidas (reflexo→oxelfer).','lessonLong'=>'O erro visto por outro ângulo inicia a correção.','lessonShort'=>'Reflita e corrija.'],
    ['key'=>'repetição','name'=>'Krysen — O Eco Ardente','img'=>'img/Cap4/Cap4-2.jpeg','phrase'=>'Cada erro é repetido duas vezes.','lessonLong'=>'Repetir é reviver e purificar.','lessonShort'=>'Aprenda na 2ª chance.'],
    ['key'=>'cadência','name'=>'Targun — A Runa Explosiva','img'=>'img/Cap4/Cap4-3.jpeg','phrase'=>'Errou? explode e causa dano extra.','lessonLong'=>'Nem toda urgência merece resposta.','lessonShort'=>'Controle o ímpeto.'],
    ['key'=>'perdão','name'=>'Mirtha — A Voz do Fogo Vivo','img'=>'img/Cap4/Cap4-4.jpeg','phrase'=>'Fala com a voz de Aedric (erros passados).','lessonLong'=>'O eco cessa quando o coração se aquieta.','lessonShort'=>'Perdoe-se.'],
    ['key'=>'sincronia','name'=>'Scaldir — Espírito das Cordas Fundidas','img'=>'img/Cap4/Cap4-5.jpeg','phrase'=>'Acelera a cada erro consecutivo.','lessonLong'=>'Verbo e som respiram juntos.','lessonShort'=>'Ache o pulso.'],
    ['key'=>'foco','name'=>'Vraen — O Demônio do Grito Partido','img'=>'img/Cap4/Cap4-6.jpeg','phrase'=>'Mistura letras de palavras diferentes.','lessonLong'=>'Distinguir o som do ruído é ouvir a verdade.','lessonShort'=>'Separe ruído.'],
    ['key'=>'discernimento','name'=>'Onthir — O Eco das Sombras','img'=>'img/Cap4/Cap4-7.jpeg','phrase'=>'Gera ecos falsos em cada acerto.','lessonLong'=>'Nem todo reflexo é verdadeiro.','lessonShort'=>'Discernir sempre.'],
    ['key'=>'pulso','name'=>'Velgor — A Forja dos Sons','img'=>'img/Cap4/Cap4-8.jpeg','phrase'=>'Séries explosivas exigem precisão.','lessonLong'=>'O verbo se forja com paciência.','lessonShort'=>'Paciência > força.'],
    ['key'=>'ressonância','name'=>'Ashara — Senhora das Vozes Perdidas','img'=>'img/Cap4/Cap4-9.jpeg','phrase'=>'Erros viram frases corrompidas.','lessonLong'=>'A mentira nasce do eco que não cessa.','lessonShort'=>'Silencie o falso.'],
    ['key'=>'reverberação','name'=>'Myrrgar — O Espelho do Fogo (Mini-Boss)','img'=>'img/Cap4/Cap4-10.jpeg','phrase'=>'Erros criam clones que repetem ataques.','lessonLong'=>'O verdadeiro inimigo habita o espelho.','lessonShort'=>'Reconcilie-se.'],
  ],

  'reward' => [
    'name'=>'Runo da Reflexão (Myrr)',
    'image'=>'img/Cap4/Cap4-runa.jpeg',
    'desc'=>"• Ignora o primeiro erro de cada fase.\n• Reduz penalidades em combos longos.\n• Desbloqueia “Eco Interno”."
  ],
];
