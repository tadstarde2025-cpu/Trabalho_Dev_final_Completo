<?php
// data/cap1.php
return [
  'title' => 'Capítulo I — O Bosque das Palavras Perdidas',
  'introImage' => 'img/Cap1/bosque.png',
  'introText' => "No coração do bosque, as palavras esquecidas ecoam.\nCada sílaba perdida clama por ser lembrada.\nE Aedric deve escutar o que o silêncio tem a dizer.",
  'heroImage' => 'img/aedric.png',
  'theme' => ['primary' => '#135c36', 'accent' => '#d4b76b'],
  'next'  => 2, // próximo capítulo

  // 10 vilões com palavra, frase, lições e imagem
  'villains' => [
    [ 'key'=>'eco',      'name'=>'Murmulho — A Palavra Incompleta',         'img'=>'img/Cap1/Eco.png',
      'phrase'=>'Fala sílabas incompletas ao jogador.',
      'lessonLong'=>'Representa o medo de começar algo sem concluir.',
      'lessonShort'=>'Comece e termine.' ],
    [ 'key'=>'vento',    'name'=>'Silabrax — O Esporo Sussurrante Alfa',    'img'=>'img/Cap1/Cap1-2.jpeg',
      'phrase'=>'Multiplica-se a cada erro.',
      'lessonLong'=>'O ritmo nasce da repetição consciente.',
      'lessonShort'=>'Ritmo vence o erro.' ],
    [ 'key'=>'símbolo',  'name'=>'Ravynas — O Corvo Rúnico Mãe',            'img'=>'img/Cap1/Cap1-3.jpeg',
      'phrase'=>'Distorce letras — atenção total.',
      'lessonLong'=>'A atenção é o verdadeiro poder do Runemestre.',
      'lessonShort'=>'Atenção cria vitória.' ],
    [ 'key'=>'memória',  'name'=>'Thornveil — A Sombra da Dúvida',          'img'=>'img/Cap1/Cap1-4.jpeg',
      'phrase'=>'Renasce a cada hesitação.',
      'lessonLong'=>'Errar é parte do aprendizado; duvidar é fracasso.',
      'lessonShort'=>'Confie e siga.' ],
    [ 'key'=>'reflexo',  'name'=>'Echoir — O Reflexo das Palavras Perdidas','img'=>'img/Cap1/Cap1-5.jpeg',
      'phrase'=>'Inverte a ordem das palavras.',
      'lessonLong'=>'Corrigir a si mesmo é a maior vitória.',
      'lessonShort'=>'Revise o reflexo.' ],
    [ 'key'=>'recordar', 'name'=>'Nymora — A Donzela do Esquecimento',      'img'=>'img/Cap1/Cap1-6.jpeg',
      'phrase'=>'Apaga letras aos poucos.',
      'lessonLong'=>'A memória é o alicerce da criação.',
      'lessonShort'=>'Recorde e reconstrua.' ],
    [ 'key'=>'verdade',  'name'=>'Scriptor — O Escriba Louco',              'img'=>'img/Cap1/Cap1-7.jpeg',
      'phrase'=>'Forja palavras falsas.',
      'lessonLong'=>'Nem toda palavra merece ser escrita.',
      'lessonShort'=>'Escolha a verdadeira.' ],
    [ 'key'=>'harmonia', 'name'=>'Lexael — O Espírito das Frases Quebradas','img'=>'img/Cap1/Cap1-8.jpeg',
      'phrase'=>'Quebra palavras em sílabas.',
      'lessonLong'=>'O todo vale mais que as partes.',
      'lessonShort'=>'Reconstrua a harmonia.' ],
    [ 'key'=>'síntese',  'name'=>'Lumen Scriptis — O Manuscrito Vivo',                       'img'=>'img/Cap1/Cap1-9.jpeg',
      'phrase'=>'Dispara palavras em rápida sucessão.',
      'lessonLong'=>'Velocidade sem precisão é caos.',
      'lessonShort'=>'Ritmo + precisão.' ],
    [ 'key'=>'runa',     'name'=>'Verin — O Guardião do Bosque',            'img'=>'img/Cap1/Cap1-10.jpeg',
      'phrase'=>'Chuva de palavras incorretas.',
      'lessonLong'=>'A precisão é uma forma de fé.',
      'lessonShort'=>'Acredite na palavra certa.' ],
  ],

  // Recompensa do capítulo
  'reward' => [
    'name' => 'Runa da Precisão',
    'image'=> 'img/Cap1/Runa1.png',
    'desc' => "Aumenta o multiplicador de combos e reduz a perda de HP por erros curtos.\nDesbloqueia as “Palavras Rítmicas”."
  ]
];
