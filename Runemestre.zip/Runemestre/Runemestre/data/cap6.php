<?php
return [
  'title'      => 'Capítulo VI — Os Arquitetos do Fim',
  'introImage' => 'img/Cap6/dragao.jpeg',
  'introText'  => "No limite do verbo, Aedric enfrenta as forças que moldam erro e silêncio. Ascender é harmonizar as Runas — ou calar-se para sempre.",
  'theme' => ['primary' => '#111827', 'accent' => '#9ae6b4'],
  'next'  => null,
  'heroImage' => 'img/aedric.png',

  'villains' => [
    ['key'=>'distorção','name'=>'CÁO — O Cérebro do Caos','img'=>'img/Cap6/Cap6-1.jpeg','phrase'=>'Sinapses trocam letras e testam lógica.','lessonLong'=>'O erro pode ser criativo, mas precisa de sentido.','lessonShort'=>'Dê forma ao caos.'],
    ['key'=>'serenidade','name'=>'HÁDES — O Guardião do Silêncio','img'=>'img/Cap6/Cap6-2.jpeg','phrase'=>'Sem som nem feedback — vença no ritmo.','lessonLong'=>'O silêncio também é linguagem.','lessonShort'=>'Sereno, ainda assim.'],
    ['key'=>'precisão','name'=>'KYR — A Mecânica da Gramática','img'=>'img/Cap6/Cap6-3.jpeg','phrase'=>'Ditado perfeito e revisão total.','lessonLong'=>'A forma sustenta a clareza.','lessonShort'=>'Precisão liberta.'],
    ['key'=>'fogo','name'=>'MAL’THOR — O Incendiário das Palavras','img'=>'img/Cap6/Cap6-4.jpeg','phrase'=>'Queima texto e distorce letras.','lessonLong'=>'Separar ruído do verbo é sobreviver.','lessonShort'=>'Purifique o som.'],
    ['key'=>'registro','name'=>'VYRN — A Escriba Sangrenta','img'=>'img/Cap6/Cap6-5.jpeg','phrase'=>'Frases somem em fragmentos de lembrança.','lessonLong'=>'Lembrar é reescrever a si mesmo.','lessonShort'=>'Memória guia.'],
    ['key'=>'corrente','name'=>'LUNETH — O Mensageiro do Vento','img'=>'img/Cap6/Cap6-6.jpeg','phrase'=>'Palavras voam e invertem ordem.','lessonLong'=>'O fluxo aceita mudança de direção.','lessonShort'=>'Dance com o ar.'],
    ['key'=>'prisma','name'=>'ELYA — A Reflexiva','img'=>'img/Cap6/Cap6-7.jpeg','phrase'=>'Tudo é revertido; às vezes, invertido semanticamente.','lessonLong'=>'O espelho revela, mas não decide.','lessonShort'=>'Reflita com critério.'],
    ['key'=>'tempo','name'=>'FRA’YR — O Guardião das Marés do Tempo','img'=>'img/Cap6/Cap6-8.jpeg','phrase'=>'Letras escorrem como areia.','lessonLong'=>'O inevitável também ensina.','lessonShort'=>'Navegue o tempo.'],
    ['key'=>'axioma','name'=>'MOR’KAEL — O Guardião do Abismo','img'=>'img/Cap6/Cap6-9.jpeg','phrase'=>'Tudo desaparece; continue de memória.','lessonLong'=>'Quando tudo cai, a verdade sustenta.','lessonShort'=>'Creia no sentido.'],
    ['key'=>'ascensão','name'=>'TYPOROS — O Nome Proibido (Final)','img'=>'img/Cap6/Cap6-10.jpeg','phrase'=>'Erro vira arma; sentido é campo de batalha.','lessonLong'=>'Reescrever o erro é reescrever o mundo.','lessonShort'=>'Ascenda o verbo.'],
  ],

  'reward' => [
    'name'=>'Ascensão Runemestre',
    'image'=>'img/Cap6/Cap6-runa.jpeg',
    'desc'=>"“Com esta runa, o verbo e o silêncio são um só.”\n• Restaura o equilíbrio do mundo.\n• Reúne todas as dez Runas em harmonia.\n• Desbloqueia o modo “Ascensão Runemestre”."
  ],

  'customCss' => '
    .scene{ background-image: radial-gradient(700px 340px at 70% 0%, rgba(154,230,180,.12), transparent 60%),
                               radial-gradient(900px 600px at 15% 110%, rgba(17,24,39,.35), transparent 60%); }
  ',
];
