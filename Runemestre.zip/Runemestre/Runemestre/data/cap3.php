<?php
return [
  'title'      => 'Capítulo III — As Catacumbas dos Nomes',
  'introImage' => 'img/Cap3/vulcao.jpeg',
  'introText'  => "Nos túmulos de papel, a memória decide quem vive na linguagem. Aedric desce à cidade dos nomes esquecidos.",
  'theme' => ['primary' => '#42285b', 'accent' => '#c69cff'],
  'next'  => 4,
  'heroImage' => 'img/aedric.png',

  'villains' => [
    ['key'=>'ritual','name'=>'Kael’thar — O Monge Corrompido Alfa','img'=>'img/Cap3/Cap3-1.jpeg','phrase'=>'Palavras longas e ritualísticas.','lessonLong'=>'A pressa diante da sabedoria é blasfêmia.','lessonShort'=>'Vá com reverência.'],
    ['key'=>'pureza','name'=>'Eldrun — O Espectro das Runas Quebradas','img'=>'img/Cap3/Cap3-2.jpeg','phrase'=>'Apresenta par correto/corrompido.','lessonLong'=>'Verdade e mentira usam as mesmas letras.','lessonShort'=>'Escolha o verdadeiro.'],
    ['key'=>'lembrança','name'=>'Morghen — O Eco das Almas Perdidas','img'=>'img/Cap3/Cap3-3.jpeg','phrase'=>'Repete erros antigos até cessar.','lessonLong'=>'O passado retorna quando chamado.','lessonShort'=>'Reconcilie-se.'],
    ['key'=>'autenticidade','name'=>'Zerath — O Guardião dos Nomes Extintos','img'=>'img/Cap3/Cap3-4.jpeg','phrase'=>'Gera palavras inexistentes (armadilhas).','lessonLong'=>'Saber o que não é também é conhecimento.','lessonShort'=>'Reconheça o falso.'],
    ['key'=>'atenção','name'=>'Thyren — A Voz Que Não Cala','img'=>'img/Cap3/Cap3-5.jpeg','phrase'=>'Frases longas com micro-erros.','lessonLong'=>'O demônio está no detalhe.','lessonShort'=>'Detalhe decide.'],
    ['key'=>'crônica','name'=>'Eruviel — O Guardião dos Manuscritos Mortos','img'=>'img/Cap3/Cap3-6.jpeg','phrase'=>'Engole palavras erradas e as corrompe.','lessonLong'=>'A escrita guarda o que a voz esquece.','lessonShort'=>'Escreva para lembrar.'],
    ['key'=>'concentração','name'=>'Vorin — O Monge das Mil Vozes','img'=>'img/Cap3/Cap3-7.jpeg','phrase'=>'Múltiplas palavras — escolha só uma.','lessonLong'=>'Falar tudo é como nada dizer.','lessonShort'=>'Uma palavra basta.'],
    ['key'=>'resiliência','name'=>'Nhalra — A Guardiã dos Túmulos de Papel','img'=>'img/Cap3/Cap3-8.jpeg','phrase'=>'Véus de frases antigas ocultam o presente.','lessonLong'=>'Ver além do véu é lembrar quem se é.','lessonShort'=>'Persista.'],
    ['key'=>'perseverança','name'=>'Themor — O Escriba Eterno','img'=>'img/Cap3/Cap3-9.jpeg','phrase'=>'Palavras infinitas: resista sem falhar.','lessonLong'=>'O cansaço é o maior inimigo do sábio.','lessonShort'=>'Resista ao cansaço.'],
    ['key'=>'sentido','name'=>'Eruen — Guardião do Submundo da Linguagem (Mini-Boss)','img'=>'img/Cap3/Cap3-10.jpeg','phrase'=>'Mistura palavras antigas e modernas.','lessonLong'=>'O que é lembrado vive.','lessonShort'=>'Busque o sentido.'],
  ],

  'reward' => [
    'name'=>'Runo da Memória (Eldra)',
    'image'=>'img/Cap3/Cap3-runa.jpeg',
    'desc'=>"• Aumenta o tempo limite dos capítulos.\n• Reduz penalidade por hesitação.\n• Desbloqueia o estado “Eco Sereno”."
  ],
];
