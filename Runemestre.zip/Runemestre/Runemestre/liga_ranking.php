<?php
// liga_ranking.php - Ranking de uma liga específica
session_start();
require_once 'config.php';

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

$liga_id = (int)($_GET['id'] ?? 0);
if (!$liga_id) {
    header("Location: ligas.php");
    exit;
}

// Buscar informações da liga
try {
    $stmt = $pdo->prepare("
        SELECT l.nome, l.criador_id, u.nome as criador_nome
        FROM ligas l
        JOIN usuarios u ON l.criador_id = u.id
        WHERE l.id = ?
    ");
    $stmt->execute([$liga_id]);
    $liga = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$liga) {
        header("Location: ligas.php");
        exit;
    }
} catch(PDOException $e) {
    header("Location: ligas.php");
    exit;
}

// Verificar se usuário faz parte da liga
try {
    $stmt = $pdo->prepare("SELECT id FROM liga_participantes WHERE usuario_id = ? AND liga_id = ?");
    $stmt->execute([$_SESSION['usuario_id'], $liga_id]);
    if (!$stmt->fetch()) {
        header("Location: ligas.php");
        exit;
    }
} catch(PDOException $e) {
    header("Location: ligas.php");
    exit;
}

// Calcular semana atual para ranking semanal
$semana_atual = (int)date('W') + ((int)date('Y') * 100);

// Ranking total da liga
$ranking_total = [];
try {
    $stmt = $pdo->prepare("
        SELECT u.nome, lp.pontuacao_total
        FROM liga_participantes lp
        JOIN usuarios u ON lp.usuario_id = u.id
        WHERE lp.liga_id = ? AND lp.pontuacao_total > 0
        ORDER BY lp.pontuacao_total ASC
        LIMIT 50
    ");
    $stmt->execute([$liga_id]);
    $ranking_total = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $ranking_total = [];
}

// Ranking semanal da liga
$ranking_semanal = [];
try {
    $stmt = $pdo->prepare("
        SELECT u.nome, lp.pontuacao_semanal
        FROM liga_participantes lp
        JOIN usuarios u ON lp.usuario_id = u.id
        WHERE lp.liga_id = ? AND lp.semana_atual = ? AND lp.pontuacao_semanal > 0
        ORDER BY lp.pontuacao_semanal ASC
        LIMIT 50
    ");
    $stmt->execute([$liga_id, $semana_atual]);
    $ranking_semanal = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $ranking_semanal = [];
}

// Estatísticas da liga
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_participantes,
               AVG(pontuacao_total) as media_pontuacao,
               MIN(pontuacao_total) as melhor_pontuacao
        FROM liga_participantes 
        WHERE liga_id = ? AND pontuacao_total > 0
    ");
    $stmt->execute([$liga_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $stats = ['total_participantes' => 0, 'media_pontuacao' => 0, 'melhor_pontuacao' => 0];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Liga: <?= htmlspecialchars($liga['nome']) ?> - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <style>
        .ranking-tabs {
            display: flex;
            gap: 1rem;
            margin: 2rem 0;
            justify-content: center;
        }
        .tab-button {
            padding: 1rem 2rem;
            background: #333;
            color: white;
            border: 2px solid #ffd700;
            border-radius: 10px;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }
        .tab-button.active {
            background: #ffd700;
            color: black;
        }
        .ranking-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            background: rgba(0,0,0,0.8);
        }
        .ranking-table th,
        .ranking-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        .ranking-table th {
            background: rgba(255,215,0,0.2);
            font-weight: bold;
            color: #ffd700;
        }
        .ranking-table tr:hover {
            background: rgba(255,215,0,0.1);
        }
        .position {
            font-weight: bold;
            text-align: center;
            width: 80px;
        }
        .position.first { color: #ffd700; }
        .position.second { color: #c0c0c0; }
        .position.third { color: #cd7f32; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }
        .stat-card {
            background: rgba(0,0,0,0.7);
            padding: 1.5rem;
            border-radius: 10px;
            border: 2px solid #ffd700;
            text-align: center;
        }
        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffd700;
            display: block;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
    </style>
</head>
<body class="page-liga-ranking">
    <header>
        <h1>🏆 Liga: <?= htmlspecialchars($liga['nome']) ?></h1>
        <nav>
            <ul>
                <li><a href="trabdev.php">🏠 Início</a></li>
                <li><a href="ligas.php">🏆 Minhas Ligas</a></li>
                <li><a href="cap_intro.php?cap=1">🎮 Jogar</a></li>
                <li><a href="logout.php">🚪 Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>📊 Informações da Liga</h2>
            <p><strong>Criador:</strong> <?= htmlspecialchars($liga['criador_nome']) ?></p>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>👥 Total de Participantes</h3>
                    <span class="stat-value"><?= number_format($stats['total_participantes']) ?></span>
                </div>
                <div class="stat-card">
                    <h3>🏆 Melhor Pontuação</h3>
                    <span class="stat-value"><?= number_format($stats['melhor_pontuacao']) ?></span>
                </div>
                <div class="stat-card">
                    <h3>📈 Pontuação Média</h3>
                    <span class="stat-value"><?= number_format($stats['media_pontuacao'], 0) ?></span>
                </div>
            </div>
        </section>

        <section>
            <div class="ranking-tabs">
                <button class="tab-button active" onclick="showTab('total')">📈 Ranking Total</button>
                <button class="tab-button" onclick="showTab('semanal')">📊 Ranking Semanal</button>
            </div>

            <div id="total" class="tab-content active">
                <h2>📈 Ranking Total (Desde Criação)</h2>
                <?php if (empty($ranking_total)): ?>
                    <p>Nenhuma pontuação registrada ainda. Jogue para aparecer no ranking!</p>
                <?php else: ?>
                    <table class="ranking-table">
                        <thead>
                            <tr>
                                <th class="position">Posição</th>
                                <th>Runemestre</th>
                                <th>Pontuação Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ranking_total as $i => $jogador): 
                                $posicao = $i + 1;
                                $css_class = '';
                                if ($posicao == 1) $css_class = 'first';
                                elseif ($posicao == 2) $css_class = 'second';
                                elseif ($posicao == 3) $css_class = 'third';
                            ?>
                                <tr>
                                    <td class="position <?= $css_class ?>">
                                        <?php if ($posicao == 1): ?>
                                            🥇 <?= $posicao ?>º
                                        <?php elseif ($posicao == 2): ?>
                                            🥈 <?= $posicao ?>º
                                        <?php elseif ($posicao == 3): ?>
                                            🥉 <?= $posicao ?>º
                                        <?php else: ?>
                                            <?= $posicao ?>º
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($jogador['nome']) ?></td>
                                    <td><?= number_format($jogador['pontuacao_total']) ?> pontos</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div id="semanal" class="tab-content">
                <h2>📊 Ranking Semanal (Semana <?= date('W/Y') ?>)</h2>
                <?php if (empty($ranking_semanal)): ?>
                    <p>Nenhuma pontuação semanal ainda. Jogue para aparecer no ranking desta semana!</p>
                <?php else: ?>
                    <table class="ranking-table">
                        <thead>
                            <tr>
                                <th class="position">Posição</th>
                                <th>Runemestre</th>
                                <th>Pontuação Semanal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ranking_semanal as $i => $jogador): 
                                $posicao = $i + 1;
                                $css_class = '';
                                if ($posicao == 1) $css_class = 'first';
                                elseif ($posicao == 2) $css_class = 'second';
                                elseif ($posicao == 3) $css_class = 'third';
                            ?>
                                <tr>
                                    <td class="position <?= $css_class ?>">
                                        <?php if ($posicao == 1): ?>
                                            🥇 <?= $posicao ?>º
                                        <?php elseif ($posicao == 2): ?>
                                            🥈 <?= $posicao ?>º
                                        <?php elseif ($posicao == 3): ?>
                                            🥉 <?= $posicao ?>º
                                        <?php else: ?>
                                            <?= $posicao ?>º
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($jogador['nome']) ?></td>
                                    <td><?= number_format($jogador['pontuacao_semanal']) ?> pontos</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </section>

        <section>
            <div style="text-align: center; margin: 2rem 0;">
                <a href="cap_intro.php?cap=1&modo=liga&liga_id=<?= $liga_id ?>" class="btn-link">🎮 Jogar Nesta Liga</a>
            </div>
        </section>
    </main>

    <script>
        function showTab(tabName) {
            // Esconder todas as abas
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remover classe active de todos os botões
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Mostrar aba selecionada
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
</body>
</html>