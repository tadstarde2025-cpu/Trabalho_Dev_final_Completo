<?php
// setup_ligas.php - Criar tabelas para sistema de ligas
require_once 'config.php';

echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <title>Setup Ligas - The Legend of Typing</title>
    <style>
        body { font-family: Arial; background: #1a1a1a; color: white; padding: 2rem; }
        h1 { color: #ffd700; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        a { color: #ffd700; }
    </style>
</head>
<body>";

echo "<h1>🏆 Configurando Sistema de Ligas</h1>";

if ($pdo === null) {
    echo "<p class='error'>❌ Erro de conexão com banco de dados.</p>";
    exit;
}

try {
    // Verificar se tabelas já existem
    $stmt = $pdo->query("SHOW TABLES LIKE 'ligas'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>ℹ️ Sistema de ligas já estava configurado!</p>";
    } else {
        // Criar tabela de ligas
        $sql_ligas = "CREATE TABLE IF NOT EXISTS ligas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            palavra_chave VARCHAR(50) NOT NULL,
            criador_id INT NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (criador_id) REFERENCES usuarios(id) ON DELETE CASCADE
        )";
        
        $pdo->exec($sql_ligas);
        echo "<p class='success'>✅ Tabela 'ligas' criada com sucesso!</p>";
        
        // Criar tabela de participantes das ligas
        $sql_participantes = "CREATE TABLE IF NOT EXISTS liga_participantes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NOT NULL,
            liga_id INT NOT NULL,
            pontuacao_total INT DEFAULT 0,
            pontuacao_semanal INT DEFAULT 0,
            semana_atual INT DEFAULT 0,
            data_entrada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
            FOREIGN KEY (liga_id) REFERENCES ligas(id) ON DELETE CASCADE,
            UNIQUE KEY unique_user_liga (usuario_id, liga_id)
        )";
        
        $pdo->exec($sql_participantes);
        echo "<p class='success'>✅ Tabela 'liga_participantes' criada com sucesso!</p>";
    }
    
    echo "<br><h2 class='success'>🎊 Sistema de Ligas configurado com sucesso!</h2>";
    echo "<p><a href='trabdev.php'>🏠 Voltar ao Início</a></p>";
    echo "<p><a href='ligas.php'>🏆 Acessar Sistema de Ligas</a></p>";
    echo "<p><a href='TUTORIAL.md'>📖 Ver Tutorial Completo</a></p>";
    
} catch(PDOException $e) {
    echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>