<?php
// login.php - Página de login
session_start();
require_once 'config.php';

// Verificar se já está logado
if (isset($_SESSION['usuario_id'])) {
    header("Location: cap_intro.php?cap=1");
    exit();
}

if ($pdo === null) {
    $erro = "Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.";
} else {
    $erro = '';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $pdo !== null) {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    if (empty($email) || empty($senha)) {
        $erro = 'Todos os campos são obrigatórios.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($usuario && password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                header("Location: trabdev.php");
                exit();
            } else {
                $erro = 'Email ou senha incorretos.';
            }
        } catch(PDOException $e) {
            $erro = 'Erro no servidor. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Entrar - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body class="page-login">
    <header>
        <div class="header-inner">
            <img src="logodosite.jpg" alt="Símbolo The Legend of Typing" class="lot-logo">
            <div class="header-text">
                <h1>The Legend of Typing</h1>
                <p>Portão dos Runemestres</p>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="login.php">Entrar</a></li>
                <li><a href="register.php">Registrar</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Acessar o Reino</h2>
            <p>Informe suas credenciais para continuar sua jornada pelos Dez Reinos das Runas.</p>

            <?php if ($erro): ?>
            <div style="background: rgba(220, 53, 69, 0.8); color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 2px solid #dc3545; text-align: center;">
                <?= htmlspecialchars($erro) ?>
            </div>
            <?php endif; ?>

            <form method="post" action="login.php">
                <div>
                    <label for="email">Email (Orbe de Contato)</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div>
                    <label for="senha">Senha Rúnica</label>
                    <input type="password" id="senha" name="senha" required>
                </div>

                <div>
                    <button type="submit">Entrar</button>
                </div>
            </form>

            <p>
                Ainda não possui um registro nas Runas?
                <a href="register.php">Forjar um novo Runemestre</a>
            </p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 The Legend of Typing</p>
    </footer>
</body>
</html>