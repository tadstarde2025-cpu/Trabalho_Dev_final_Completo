<?php
// save_score.php - Salvamento de pontuação (apenas campanha)
session_start();
header('Content-Type: application/json');

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
  echo json_encode(['ok' => false, 'error' => 'not logged in']);
  exit;
}

require_once 'config.php';

if ($pdo === null) {
    echo json_encode(['ok' => false, 'error' => 'database connection failed']);
    exit;
}

// Lê JSON bruto
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
  echo json_encode(['ok' => false, 'error' => 'invalid payload']);
  exit;
}

if (!isset($data['ms'])) {
  echo json_encode(['ok' => false, 'error' => 'missing ms']);
  exit;
}

$ms      = max(0, (int)$data['ms']);
$correct = isset($data['correct']) ? max(0, (int)$data['correct']) : 0;
$cap     = isset($data['cap']) ? (int)$data['cap'] : 1;
$modo    = isset($data['modo']) ? $data['modo'] : 'campanha'; // 'campanha' ou 'liga'
$liga_id = isset($data['liga_id']) ? (int)$data['liga_id'] : null;

// converte para segundos inteiros
$seconds = intdiv($ms, 1000);

// multiplicador por capítulo: cap 1 => 1, cap 2 => 2 ... limitado a 6
$multiplier = $cap;
if ($multiplier < 1)  $multiplier = 1;
if ($multiplier > 6) $multiplier = 6;

// pontos deste capítulo
$chapterPoints = $seconds * $multiplier;

// inicializa sessão, se precisar
if (!isset($_SESSION['total_ms']))      $_SESSION['total_ms'] = 0;
if (!isset($_SESSION['total_correct'])) $_SESSION['total_correct'] = 0;
if (!isset($_SESSION['total_points']))  $_SESSION['total_points'] = 0;

// acumula SEMPRE (para estatísticas)
$_SESSION['total_ms']      += $ms;
$_SESSION['total_correct'] += $correct;
$_SESSION['total_points']  += $chapterPoints;

// Salvar pontuação no banco de dados APENAS se completou o capítulo 6
try {
    // APENAS salva no banco quando zera o jogo (capítulo 6)
    if ($cap == 6) {
        $pontuacao_final = (int)$_SESSION['total_points'];
        
        if ($modo == 'liga' && $liga_id) {
            // Modo liga: salvar EXCLUSIVAMENTE na tabela liga_participantes
            $semana_atual = (int)date('W') + ((int)date('Y') * 100);
            
            // Verificar se usuário está na liga
            $stmt = $pdo->prepare("SELECT pontuacao_total, pontuacao_semanal, semana_atual FROM liga_participantes WHERE usuario_id = ? AND liga_id = ?");
            $stmt->execute([$_SESSION['usuario_id'], $liga_id]);
            $participante = $stmt->fetch();
            
            if ($participante) {
                $nova_pontuacao_total = $participante['pontuacao_total'];
                $nova_pontuacao_semanal = $participante['pontuacao_semanal'];
                
                // Atualizar pontuação total se for melhor (menor)
                if (!$participante['pontuacao_total'] || $pontuacao_final < $participante['pontuacao_total']) {
                    $nova_pontuacao_total = $pontuacao_final;
                }
                
                // Reset semanal ou atualizar se for melhor
                if ($participante['semana_atual'] != $semana_atual) {
                    $nova_pontuacao_semanal = $pontuacao_final;
                } else if (!$participante['pontuacao_semanal'] || $pontuacao_final < $participante['pontuacao_semanal']) {
                    $nova_pontuacao_semanal = $pontuacao_final;
                }
                
                $stmt = $pdo->prepare("UPDATE liga_participantes SET pontuacao_total = ?, pontuacao_semanal = ?, semana_atual = ? WHERE usuario_id = ? AND liga_id = ?");
                $stmt->execute([$nova_pontuacao_total, $nova_pontuacao_semanal, $semana_atual, $_SESSION['usuario_id'], $liga_id]);
            }
            
            // NÃO salvar no histórico geral nem na pontuação do usuário quando for modo liga
            
        } else {
            // Modo campanha: salvar EXCLUSIVAMENTE na campanha
            // Salvar no histórico
            $stmt = $pdo->prepare("INSERT INTO historico_partidas (usuario_id, capitulo, tempo_ms, acertos, pontos_ganhos) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_SESSION['usuario_id'], $cap, $ms, $correct, $pontuacao_final]);
            
            // Buscar pontuação atual do usuário
            $stmt = $pdo->prepare("SELECT pontuacao FROM usuarios WHERE id = ?");
            $stmt->execute([$_SESSION['usuario_id']]);
            $usuario = $stmt->fetch();
            $pontuacao_atual = $usuario['pontuacao'] ?? 0;
            
            // Atualizar apenas se a nova pontuação for MENOR (melhor)
            if (!$pontuacao_atual || $pontuacao_final < $pontuacao_atual) {
                $stmt = $pdo->prepare("UPDATE usuarios SET pontuacao = ? WHERE id = ?");
                $stmt->execute([$pontuacao_final, $_SESSION['usuario_id']]);
            }
        }
        
        // Reset session
        unset($_SESSION['total_ms']);
        unset($_SESSION['total_correct']);
        unset($_SESSION['total_points']);
    }
} catch(PDOException $e) {
    echo json_encode(['ok' => false, 'error' => 'database error: ' . $e->getMessage()]);
    exit;
}

echo json_encode([
  'ok' => true,
  'cap' => $cap,
  'ms' => $ms,
  'correct' => $correct,
  'chapterPoints' => $chapterPoints,
  'sessionTotalPoints' => (int)$_SESSION['total_points']
]);
?>