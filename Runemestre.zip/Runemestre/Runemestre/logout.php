<?php
// logout.php - Sair do sistema
session_start();
session_destroy();
header("Location: index.php");
exit();
?>