<?php
// trabdev.php - Página inicial do site
session_start();
require_once 'config.php';

// Verificar se o usuário está logado
$usuario_logado = isset($_SESSION['usuario_id']);
$nome_usuario = $usuario_logado ? $_SESSION['usuario_nome'] : null;

// Buscar top 3 jogadores
$ranking = [];
if ($pdo !== null) {
    try {
        $stmt = $pdo->prepare("SELECT nome, pontuacao FROM usuarios WHERE pontuacao > 0 ORDER BY pontuacao ASC LIMIT 3");
        $stmt->execute();
        $ranking = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        $ranking = [];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>The Legend of Typing - Portal do Runemestre</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body class="page-home">
    <header>
        <div class="header-inner">
            <img src="logodosite.jpg" alt="Símbolo The Legend of Typing" class="lot-logo">
            <div class="header-text">
                <h1>The Legend of Typing</h1>
                <p>Domine as Runas. Enfrente os Dez Reinos. Desafie Typoros.</p>
            </div>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="rankings.php">Rankings</a></li>
                <?php if ($usuario_logado): ?>
                    <li><a href="cap_intro.php?cap=1">Campanha</a></li>
                    <li><a href="ligas.php">Ligas</a></li>
                    <li><a href="historico.php">Histórico</a></li>
                    <li><a href="logout.php">Sair (<?= htmlspecialchars($nome_usuario) ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php">Entrar</a></li>
                    <li><a href="register.php">Registrar</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <!-- IMAGENS LATERAIS (FORA DAS SECTIONS) -->
    <div class="side-art side-art-left">
        <img src="mago.jpg" alt="Mago Rúnico Guardião das Runas">
    </div>

    <div class="side-art side-art-right">
        <img src="demonio.jpg" alt="Demônio Guardião das Sombras Verbais">
    </div>

    <main>

        <!-- Apresentação -->
        <section>
            <?php if ($usuario_logado): ?>
                <h2>Bem-vindo de volta, <?= htmlspecialchars($nome_usuario) ?>!</h2>
                <p>
                    Escolha seu modo de jogo: <strong>Campanha</strong> para jornada solo ou <strong>Ligas</strong> para competir!
                </p>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin: 2rem 0;">
                    <div style="background: rgba(0,50,150,0.3); padding: 2rem; border-radius: 10px; border: 2px solid #4a90e2; text-align: center;">
                        <h3>📖 Campanha</h3>
                        <p>Continue sua jornada pelos Dez Reinos das Runas. Progresso salvo e histórico completo.</p>
                        <a href="cap_intro.php?cap=1" class="btn-link">🎮 Jogar Campanha</a>
                    </div>
                    <div style="background: rgba(150,100,0,0.3); padding: 2rem; border-radius: 10px; border: 2px solid #ffd700; text-align: center;">
                        <h3>🏆 Ligas</h3>
                        <p>Compete com outros jogadores em ligas personalizadas. Rankings e pontuações semanais!</p>
                        <a href="ligas.php" class="btn-link">⚔️ Acessar Ligas</a>
                    </div>
                </div>
                <div style="text-align: center; margin: 1rem 0;">
                    <a href="historico.php" class="btn-link">📊 Ver Meu Histórico</a>
                    <a href="rankings.php" class="btn-link">🏅 Rankings</a>
                </div>
            <?php else: ?>
                <h2>Bem-vindo ao Reino de Veridion</h2>
                <p>
                    The Legend of Typing é um jogo de digitação em um mundo de fantasia medieval,
                    onde cada palavra é um golpe, cada frase é um feitiço e cada erro fortalece as trevas.
                </p>
                <p>
                    Registre-se como Runemestre, autentique-se e prove sua habilidade através dos
                    Dez Capítulos, enfrentando inimigos rúnicos e buscando o topo do ranking.
                </p>
                <div>
                    <a href="register.php" class="btn-link">Começar Jornada</a>
                    <a href="login.php" class="btn-link">Já sou Runemestre</a>
                </div>
            <?php endif; ?>
        </section>

        <!-- Como funciona -->
        <section>
            <h2>Como funciona</h2>
            <ul>
                <li>Crie sua conta para acessar o sistema.</li>
                <li>Faça login como Runemestre autenticado.</li>
                <li>Jogue partidas do jogo de digitação e acumule pontos.</li>

                <li>Acompanhe seu histórico de partidas e evolução.</li>
                <li>Veja o ranking geral de jogadores e dispute sua posição.</li>
            </ul>
        </section>

        <!-- Ranking geral -->
        <section>
            <h2>Ranking Geral de Runemestres</h2>
            <p>Os maiores pontuadores desde a criação do sistema.</p>

            <table>
                <thead>
                    <tr>
                        <th>Posição</th>
                        <th>Nome do Runemestre</th>
                        <th>Pontuação Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    for ($i = 0; $i < 3; $i++): 
                        $posicao = $i + 1;
                        if (isset($ranking[$i])):
                            $nome = htmlspecialchars($ranking[$i]['nome']);
                            $pontos = number_format($ranking[$i]['pontuacao']);
                        else:
                            $nome = '---';
                            $pontos = '---';
                        endif;
                    ?>
                    <tr>
                        <td><?= $posicao ?></td>
                        <td><?= $nome ?></td>
                        <td><?= $pontos ?></td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
            </table>

            <p>Ranking atualizado em tempo real com as pontuações dos jogadores.</p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 The Legend of Typing</p>
    </footer>
</body>
</html>