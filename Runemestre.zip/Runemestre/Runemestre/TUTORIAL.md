# 🎮 The Legend of Typing - Tutorial de Instalação

## 📋 Pré-requisitos
- XAMPP instalado (Apache + MySQL)
- PHP 7.4 ou superior
- Navegador web

## 🚀 Passo a Passo para Rodar o Site

### 1️⃣ **Iniciar o XAMPP**
1. Abra o painel de controle do XAMPP
2. Inicie os serviços:
   - **Apache** ✅
   - **MySQL** ✅

### 2️⃣ **Verificar Configuração**
- Certifique-se que os arquivos estão em: `C:\xampp\htdocs\Runemestre\`
- O MySQL deve estar rodando na porta **3307** (configuração padrão do projeto)

### 3️⃣ **Configurar o Banco de Dados** ⚡ IMPORTANTE!
**PRIMEIRO LINK A EXECUTAR:**
```
http://localhost/Runemestre/setup_database.php
```

Este link vai:
- ✅ Criar o banco de dados `runemestre_db`
- ✅ Criar a tabela `usuarios`
- ✅ Criar a tabela `historico_partidas`
- ✅ Configurar a estrutura básica

**AGUARDE** aparecer a mensagem: `✅ Sistema pronto para usar!`

### 4️⃣ **Configurar o Sistema de Ligas** 
**SEGUNDO LINK A EXECUTAR:**
```
http://localhost/Runemestre/setup_ligas.php
```

Este link vai:
- ✅ Criar a tabela `ligas`
- ✅ Criar a tabela `liga_participantes`
- ✅ Configurar sistema de ligas completo

### 5️⃣ **Acessar o Site Principal**
**TERCEIRO LINK - SITE PRINCIPAL:**
```
http://localhost/Runemestre/
```
ou
```
http://localhost/Runemestre/index.php
```

## 🎯 Fluxo de Uso do Site

### Para Novos Usuários:
1. **Registrar:** `http://localhost/Runemestre/register.php`
2. **Fazer Login:** `http://localhost/Runemestre/login.php`
3. **Escolher Modo de Jogo** na página principal

### Modos de Jogo:

#### 📖 **Campanha (Modo Solo)**
- Clique em **"🎮 Jogar Campanha"**
- Complete os 6 capítulos
- Sua pontuação vai para o ranking geral
- Link direto: `http://localhost/Runemestre/cap_intro.php?cap=1`

#### 🏆 **Ligas (Modo Competitivo)**
- Clique em **"⚔️ Acessar Ligas"**
- Crie uma nova liga ou entre em uma existente
- Jogue no modo liga para competir com outros
- Link direto: `http://localhost/Runemestre/ligas.php`

## 📊 Páginas Importantes

### Rankings e Estatísticas:
- **Ranking Geral:** `http://localhost/Runemestre/rankings.php`
- **Histórico Pessoal:** `http://localhost/Runemestre/historico.php`
- **Sistema de Ligas:** `http://localhost/Runemestre/ligas.php`

### Administração:
- **Menu Principal:** `http://localhost/Runemestre/trabdev.php`
- **Logout:** `http://localhost/Runemestre/logout.php`

## 🛠️ Solução de Problemas

### ❌ Erro de Conexão com Banco:
1. Verifique se o MySQL está rodando
2. Confirme que a porta é **3307**
3. Execute novamente: `http://localhost/Runemestre/setup_database.php`

### ❌ Página em Branco:
1. Verifique se o Apache está rodando
2. Confirme o caminho: `C:\xampp\htdocs\Runemestre\`
3. Verifique se todos os arquivos foram copiados

### ❌ Sistema de Ligas não Funciona:
1. Execute: `http://localhost/Runemestre/setup_ligas.php`
2. Verifique se as tabelas foram criadas

## 🎮 Ordem de Execução Resumida

```
1. Iniciar XAMPP (Apache + MySQL)
2. http://localhost/Runemestre/setup_database.php
3. http://localhost/Runemestre/setup_ligas.php  
4. http://localhost/Runemestre/
5. Registrar usuário
6. Jogar! 🎯
```

## 🏆 Funcionalidades Principais

- ✅ **Sistema de Usuários:** Registro, login, sessões
- ✅ **Campanha Solo:** 6 capítulos progressivos
- ✅ **Sistema de Ligas:** Competição entre usuários
- ✅ **Rankings:** Geral e por liga
- ✅ **Histórico:** Acompanhamento de progresso
- ✅ **Pontuação Dupla:** Semanal e total
- ✅ **Interface Medieval:** Design temático completo

**🎊 Pronto! Seu site está funcionando perfeitamente!**