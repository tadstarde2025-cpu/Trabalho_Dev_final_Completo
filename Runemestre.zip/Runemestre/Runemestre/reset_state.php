<?php
// reset_state.php - Resetar o progresso do jogo
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Pegar parâmetros da URL
$mode = $_GET['mode'] ?? 'all';
$cap = (int)($_GET['cap'] ?? 1);
$modo_jogo = $_GET['modo'] ?? null;
$liga_id = $_GET['liga_id'] ?? null;

// Resetar variáveis de sessão do progresso do jogo
if ($mode === 'all') {
    // Resetar todo o progresso
    unset($_SESSION['total_ms']);
    unset($_SESSION['total_correct']);
    unset($_SESSION['total_points']);
    $_SESSION['hp'] = 100; // Resetar HP também
    
    // Mensagem de confirmação
    $message = "Todo o progresso foi resetado!";
} elseif ($mode === 'chapter') {
    // Resetar apenas o capítulo atual (HP volta para 100, mas mantém progresso geral)
    $_SESSION['hp'] = 100;
    
    $message = "HP restaurado! Capítulo reiniciado.";
} else {
    // Se houver outros tipos de reset no futuro, implementar aqui
    $message = "Reset realizado!";
}

// Redirecionar de volta para o capítulo ou página inicial
if (isset($_GET['redirect'])) {
    $redirect = $_GET['redirect'];
} else {
    // Preservar parâmetros de modo e liga se existirem
    $params = '';
    if ($modo_jogo) {
        $params .= "&modo=$modo_jogo";
    }
    if ($liga_id) {
        $params .= "&liga_id=$liga_id";
    }
    
    // Se for reset de capítulo, volta para o mesmo capítulo
    if ($mode === 'chapter') {
        $redirect = "capitulo.php?cap=$cap" . $params;
    } else {
        // Se veio do cap_intro, redireciona para cap_intro
        // Se veio do capitulo, redireciona para o capítulo 1
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        if (strpos($referer, 'cap_intro.php') !== false) {
            $redirect = "cap_intro.php?cap=1" . $params;
        } else {
            $redirect = "capitulo.php?cap=1" . $params;
        }
    }
}

// Adicionar mensagem de sucesso na sessão para mostrar na próxima página
$_SESSION['reset_message'] = $message;

// Redirecionar
header("Location: $redirect");
exit;
?>