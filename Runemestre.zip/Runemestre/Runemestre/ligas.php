<?php
// ligas.php - Sistema de Ligas
session_start();
require_once 'config.php';

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if ($pdo === null) {
    die("Erro de conexão com banco de dados. Verifique se o XAMPP está rodando.");
}

$mensagem = '';
$erro = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    if ($acao == 'criar_liga') {
        $nome = trim($_POST['nome'] ?? '');
        $palavra_chave = trim($_POST['palavra_chave'] ?? '');
        
        if (strlen($nome) >= 3 && strlen($palavra_chave) >= 3) {
            try {
                $stmt = $pdo->prepare("INSERT INTO ligas (nome, palavra_chave, criador_id) VALUES (?, ?, ?)");
                $stmt->execute([$nome, $palavra_chave, $_SESSION['usuario_id']]);
                
                $liga_id = $pdo->lastInsertId();
                
                // Adicionar criador automaticamente à liga
                $stmt = $pdo->prepare("INSERT INTO liga_participantes (usuario_id, liga_id) VALUES (?, ?)");
                $stmt->execute([$_SESSION['usuario_id'], $liga_id]);
                
                $mensagem = "Liga '{$nome}' criada com sucesso!";
            } catch(PDOException $e) {
                $erro = "Erro ao criar liga: " . $e->getMessage();
            }
        } else {
            $erro = "Nome da liga e palavra-chave devem ter pelo menos 3 caracteres.";
        }
    }
    
    if ($acao == 'entrar_liga') {
        $liga_id = (int)($_POST['liga_id'] ?? 0);
        $palavra_chave = trim($_POST['palavra_chave'] ?? '');
        
        if ($liga_id && $palavra_chave) {
            try {
                // Verificar palavra-chave
                $stmt = $pdo->prepare("SELECT nome FROM ligas WHERE id = ? AND palavra_chave = ?");
                $stmt->execute([$liga_id, $palavra_chave]);
                $liga = $stmt->fetch();
                
                if ($liga) {
                    // Verificar se já está na liga
                    $stmt = $pdo->prepare("SELECT id FROM liga_participantes WHERE usuario_id = ? AND liga_id = ?");
                    $stmt->execute([$_SESSION['usuario_id'], $liga_id]);
                    
                    if (!$stmt->fetch()) {
                        $stmt = $pdo->prepare("INSERT INTO liga_participantes (usuario_id, liga_id) VALUES (?, ?)");
                        $stmt->execute([$_SESSION['usuario_id'], $liga_id]);
                        $mensagem = "Você entrou na liga '{$liga['nome']}' com sucesso!";
                    } else {
                        $erro = "Você já está nesta liga.";
                    }
                } else {
                    $erro = "Palavra-chave incorreta.";
                }
            } catch(PDOException $e) {
                $erro = "Erro ao entrar na liga: " . $e->getMessage();
            }
        } else {
            $erro = "Preencha todos os campos.";
        }
    }
}

// Buscar ligas do usuário
$ligas_usuario = [];
try {
    $stmt = $pdo->prepare("
        SELECT l.id, l.nome, l.criador_id, lp.pontuacao_total, lp.pontuacao_semanal,
               (SELECT COUNT(*) FROM liga_participantes WHERE liga_id = l.id) as total_participantes
        FROM ligas l 
        JOIN liga_participantes lp ON l.id = lp.liga_id 
        WHERE lp.usuario_id = ?
        ORDER BY l.nome
    ");
    $stmt->execute([$_SESSION['usuario_id']]);
    $ligas_usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $ligas_usuario = [];
}

// Buscar todas as ligas para entrada
$todas_ligas = [];
try {
    $stmt = $pdo->prepare("
        SELECT l.id, l.nome, 
               (SELECT COUNT(*) FROM liga_participantes WHERE liga_id = l.id) as total_participantes,
               (SELECT COUNT(*) FROM liga_participantes WHERE liga_id = l.id AND usuario_id = ?) as ja_participa
        FROM ligas l 
        ORDER BY l.nome
    ");
    $stmt->execute([$_SESSION['usuario_id']]);
    $todas_ligas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $todas_ligas = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Ligas - The Legend of Typing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <style>
        .liga-card {
            background: rgba(0,0,0,0.8);
            border: 2px solid #ffd700;
            border-radius: 10px;
            padding: 1.5rem;
            margin: 1rem 0;
        }
        .liga-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin: 1rem 0;
        }
        .form-section {
            background: rgba(0,50,100,0.3);
            padding: 2rem;
            border-radius: 10px;
            margin: 2rem 0;
        }
        .mensagem {
            background: rgba(0,150,0,0.3);
            border: 2px solid #28a745;
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
        }
        .erro {
            background: rgba(150,0,0,0.3);
            border: 2px solid #dc3545;
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
        }
        .liga-stats {
            font-size: 0.9em;
            color: #ccc;
            margin-top: 0.5rem;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 0.8rem;
            margin: 0.5rem 0;
            border: 2px solid #444;
            border-radius: 5px;
            background: rgba(0,0,0,0.7);
            color: white;
        }
        button {
            background: #ffd700;
            color: black;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin: 0.5rem 0;
        }
        button:hover {
            background: #ffed4e;
        }
    </style>
</head>
<body class="page-ligas">
    <header>
        <h1>🏆 Sistema de Ligas</h1>
        <nav>
            <ul>
                <li><a href="trabdev.php">🏠 Início</a></li>
                <li><a href="cap_intro.php?cap=1">🎮 Campanha</a></li>
                <li><a href="rankings.php">🏅 Ranking Geral</a></li>
                <li><a href="historico.php">📊 Histórico</a></li>
                <li><a href="logout.php">🚪 Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>
        
        <?php if ($erro): ?>
            <div class="erro"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <section>
            <h2>🏆 Minhas Ligas</h2>
            <?php if (empty($ligas_usuario)): ?>
                <p>Você ainda não está em nenhuma liga. Crie uma nova ou entre em uma existente!</p>
            <?php else: ?>
                <div class="liga-grid">
                    <?php foreach ($ligas_usuario as $liga): ?>
                        <div class="liga-card">
                            <h3><?= htmlspecialchars($liga['nome']) ?></h3>
                            <div class="liga-stats">
                                👥 <?= $liga['total_participantes'] ?> participantes<br>
                                <?php if ($liga['criador_id'] == $_SESSION['usuario_id']): ?>
                                    👑 <em>Você é o criador</em><br>
                                <?php endif; ?>
                                📈 Pontuação Total: <strong><?= number_format($liga['pontuacao_total']) ?></strong><br>
                                📊 Pontuação Semanal: <strong><?= number_format($liga['pontuacao_semanal']) ?></strong>
                            </div>
                            <div style="margin-top: 1rem;">
                                <a href="liga_ranking.php?id=<?= $liga['id'] ?>" class="btn-link">📋 Ver Ranking</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="form-section">
            <h2>🆕 Criar Nova Liga</h2>
            <form method="POST">
                <input type="hidden" name="acao" value="criar_liga">
                <label>Nome da Liga:</label>
                <input type="text" name="nome" required minlength="3" maxlength="100">
                <label>Palavra-chave (para outros entrarem):</label>
                <input type="password" name="palavra_chave" required minlength="3" maxlength="50">
                <button type="submit">🚀 Criar Liga</button>
            </form>
        </section>

        <section class="form-section">
            <h2>🎯 Entrar em Liga Existente</h2>
            <?php if (!empty($todas_ligas)): ?>
                <form method="POST">
                    <input type="hidden" name="acao" value="entrar_liga">
                    <label>Selecionar Liga:</label>
                    <select name="liga_id" style="width: 100%; padding: 0.8rem; margin: 0.5rem 0; border: 2px solid #444; border-radius: 5px; background: rgba(0,0,0,0.7); color: white;">
                        <option value="">-- Escolha uma liga --</option>
                        <?php foreach ($todas_ligas as $liga): ?>
                            <?php if ($liga['ja_participa'] == 0): ?>
                                <option value="<?= $liga['id'] ?>">
                                    <?= htmlspecialchars($liga['nome']) ?> (<?= $liga['total_participantes'] ?> participantes)
                                </option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                    <label>Palavra-chave:</label>
                    <input type="password" name="palavra_chave" required>
                    <button type="submit">🎮 Entrar na Liga</button>
                </form>
            <?php else: ?>
                <p>Nenhuma liga disponível. Seja o primeiro a criar uma!</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>