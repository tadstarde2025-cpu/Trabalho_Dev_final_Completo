<?php
// setup_database.php - Script para criar o banco e tabela
$host = 'localhost';
$port = '3307';
$username = 'root';
$passwords = ['', 'root', '123456']; // Senhas comuns do XAMPP

$pdo = null;
foreach ($passwords as $password) {
    try {
        $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        break; // Conexão bem-sucedida
    } catch(PDOException $e) {
        continue; // Tenta próxima senha
    }
}

if ($pdo === null) {
    echo "<!DOCTYPE html>
    <html lang='pt-BR'>
    <head>
        <meta charset='UTF-8'>
        <title>Setup Database - The Legend of Typing</title>
        <style>
            body { font-family: Arial; background: #1a1a1a; color: white; padding: 2rem; }
            h1 { color: #ffd700; }
            .error { color: #dc3545; }
        </style>
    </head>
    <body>
        <h1>❌ Erro de Conexão</h1>
        <p class='error'>Não foi possível conectar ao MySQL. Verifique se o XAMPP está rodando.</p>
    </body>
    </html>";
    die();
}

echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <title>Setup Database - The Legend of Typing</title>
    <style>
        body { font-family: Arial; background: #1a1a1a; color: white; padding: 2rem; }
        h1 { color: #ffd700; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        a { color: #ffd700; }
    </style>
</head>
<body>
<h1>🗃️ Configurando Banco de Dados</h1>";

try {
    // Criar banco de dados
    $pdo->exec("CREATE DATABASE IF NOT EXISTS runemestre_db");
    echo "<p class='success'>✅ Banco de dados 'runemestre_db' criado com sucesso!</p>";
    
    // Usar o banco
    $pdo->exec("USE runemestre_db");
    
    // Criar tabela de usuários
    $sql = "CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        senha VARCHAR(255) NOT NULL,
        pontuacao INT DEFAULT 0,
        data_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "<p class='success'>✅ Tabela 'usuarios' criada com sucesso!</p>";
    
    // Criar tabela de histórico
    $sql_historico = "CREATE TABLE IF NOT EXISTS historico_partidas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        capitulo INT NOT NULL,
        tempo_ms INT NOT NULL,
        acertos INT DEFAULT 0,
        pontos_ganhos INT NOT NULL,
        data_partida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    )";
    
    $pdo->exec($sql_historico);
    echo "<p class='success'>✅ Tabela 'historico_partidas' criada com sucesso!</p>";
    
    echo "<br><h2 class='success'>🎮 Sistema pronto para usar!</h2>";
    echo "<p><strong>📋 Próximos passos:</strong></p>";
    echo "<p>1. <a href='setup_ligas.php'>Configurar Sistema de Ligas</a></p>";
    echo "<p>2. <a href='index.php'>Ir para o site</a></p>";
    echo "<p>3. <a href='register.php'>Registrar uma conta</a></p>";
    echo "<p>4. Fazer login e jogar!</p>";
    echo "<p><a href='TUTORIAL.md'>📖 Ver Tutorial Completo</a></p>";
    
} catch(PDOException $e) {
    echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>