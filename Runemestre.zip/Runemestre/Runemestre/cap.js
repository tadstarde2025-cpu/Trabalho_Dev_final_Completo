// cap.js — lógica do capítulo (HP, combos, tempo, reset, recompensa, somatório)

const $ = sel => document.querySelector(sel);
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function normalize(s) { return String(s || '').toLowerCase().trim().replace(/\s+/g, ' '); }

// ===== DOM =====
const heroImg    = $('#heroImg');
const heroFrame  = $('#heroFrame');
const enemyImg   = $('#enemyImg');
const enemyFrame = $('#enemyFrame');
const enemyName  = $('#enemyName');
const enemyPhrase= $('#enemyPhrase');

const hpBar   = $('#hero-hp-bar');
const hpText  = $('#hpText');
const comboEl = $('#combo');
const runaEl  = $('#runa');
const timerEl = $('#timer');

const promptEl   = $('#prompt');
const inputEl    = $('#input');
const feedbackEl = $('#feedback');

const resetPhaseBtn = $('#resetPhaseBtn');
const resetAllBtn   = $('#resetAllBtn');

const lessonsUl     = $('#lessons');
const collectBtn    = $('#collectBtn');
const rewardBox     = $('#rewardBox');
const rewardName    = $('#rewardName');
const rewardImg     = $('#rewardImg');
const rewardDesc    = $('#rewardDesc');
const chapterTimeEl = $('#chapterTime');
const totalTimeEl   = $('#totalTime');
const totalCombosEl = $('#totalCombos');
const chapterPointsEl     = $('#chapterPoints');
const totalPointsEl       = $('#totalPoints');
const chapterMultiplierEl = $('#chapterMultiplier');

// ===== CAP data vindos do PHP =====
const CAP      = window.CAP_DATA || {};
let   villainsSource = Array.isArray(CAP.villains) ? CAP.villains.slice() : [];

// Número do capítulo e multiplicador estilo Mario
const capNumFromPhp = typeof window.CAP_NUM === 'number'
  ? window.CAP_NUM
  : Number(window.CAP_NUM || 1);

const CHAPTER_MULTIPLIER = (typeof window.CHAPTER_MULTIPLIER === 'number'
  ? window.CHAPTER_MULTIPLIER
  : Math.min(10, Math.max(1, capNumFromPhp)));

// Fallback: se não tiver vilões configurados no data/capX.php
// e for o capítulo 1, usamos os 10 vilões do Bosque.
if ((!villainsSource || villainsSource.length === 0) && (window.CAP_NUM === 1)) {
  villainsSource = [
    {
      key: 'eco',
      name: 'Murmulho — A Palavra Incompleta',
      img: 'img/most1.png',
      phrase: 'Murmulho representa o medo de começar algo sem concluir.',
      lessonShort: 'Murmulho: começar é mais forte que temer o fim.'
    },
    {
      key: 'vento',
      name: 'Silabrax — O Esporo Sussurrante Alfa',
      img: 'img/vento.png',
      phrase: 'Silabrax se multiplica a cada erro, enchendo o bosque de ruído.',
      lessonShort: 'Silabrax: repetição com ritmo purifica o caos.'
    },
    {
      key: 'símbolo',
      name: 'Ravynas — O Corvo Rúnico Mãe',
      img: 'img/simbolo.png',
      phrase: 'Ravynas distorce cada letra, testando tua atenção.',
      lessonShort: 'Ravynas: a atenção é o verdadeiro poder do Runemestre.'
    },
    {
      key: 'memória',
      name: 'Thornveil — A Sombra da Dúvida',
      img: 'img/memoria.png',
      phrase: 'Thornveil reaparece a cada hesitação.',
      lessonShort: 'Thornveil: errar é parte do aprendizado, duvidar é o verdadeiro fracasso.'
    },
    {
      key: 'reflexo',
      name: 'Echoir — O Reflexo das Palavras Perdidas',
      img: 'img/reflexo.png',
      phrase: 'Echoir inverte as palavras e mostra teu próprio erro.',
      lessonShort: 'Echoir: reconhecer o erro é o primeiro acerto.'
    },
    {
      key: 'recordar',
      name: 'Nymora — A Donzela do Esquecimento',
      img: 'img/recordar.png',
      phrase: 'Nymora apaga letras da tela, pedindo que tu te lembres.',
      lessonShort: 'Nymora: a memória é o alicerce da criação.'
    },
    {
      key: 'verdade',
      name: 'Scriptor — O Escriba Louco',
      img: 'img/verdade.png',
      phrase: 'Scriptor cria palavras falsas que tentam te enganar.',
      lessonShort: 'Scriptor: nem toda palavra merece ser escrita.'
    },
    {
      key: 'harmonia',
      name: 'Lexael — O Espírito das Frases Quebradas',
      img: 'img/harmonia.png',
      phrase: 'Lexael divide frases em partes, quebrando o sentido.',
      lessonShort: 'Lexael: o todo é mais importante que as partes.'
    },
    {
      key: 'síntese',
      name: 'O Manuscrito Vivo',
      img: 'img/sintese.png',
      phrase: 'O Manuscrito Vivo lança palavras em rápida sucessão.',
      lessonShort: 'O Manuscrito Vivo: velocidade sem precisão é caos.'
    },
    {
      key: 'runa',
      name: 'Verin — O Guardião do Bosque',
      img: 'img/runa.png',
      phrase: 'Verin faz chover palavras incorretas sobre o bosque.',
      lessonShort: 'Verin: a precisão é uma forma de fé.'
    }
  ];
}

// Garantimos que são no máximo 10
const VILLAINS = villainsSource.slice(0, 10);

// ===== STATE =====
const state = {
  started: false,
  finished: false,
  index: 0,
  hp: typeof window.START_HP === 'number' ? window.START_HP : 100,
  combo: 0,
  timerId: null,
  ms: 0,
  correctCount: 0
};

// ===== chamadas ao servidor =====
function saveHP() {
  fetch('save_state.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ hp: state.hp })
  }).catch(() => {});
}

function sendScore() {
  const payload = {
    ms: state.ms,
    correct: state.correctCount,
    cap: window.CAP_NUM || 0,
    modo: window.MODO || 'campanha'
  };
  
  if (window.LIGA_ID) {
    payload.liga_id = window.LIGA_ID;
  }
  
  fetch('save_score.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(data => {
    if (!data) return;

    // Atualizar elementos da interface
    if (typeof data.total_points === 'number' && totalPointsEl) {
      totalPointsEl.textContent = data.total_points;
    }
    if (typeof data.points === 'number' && chapterPointsEl) {
      chapterPointsEl.textContent = data.points;
    }

    // Mostrar mensagem baseada no status
    if (data.message) {
      console.log(data.message);
    }
    
    // Se completou o jogo (cap 6), mostrar mensagem especial
    if (data.game_completed && data.saved_to_database) {
      setTimeout(() => {
        alert('🎉 Parabéns! Você completou o jogo! Sua pontuação foi salva no ranking!');
      }, 1000);
    }
  })
  .catch(() => {});
}

// ===== cronômetro =====
function startTimer() {
  if (state.timerId) return;
  const t0 = Date.now() - state.ms;
  state.timerId = setInterval(() => {
    state.ms = Date.now() - t0;
    const sec = Math.floor(state.ms / 1000);
    timerEl.textContent = `${pad2(Math.floor(sec/60))}:${pad2(sec%60)}`;
  }, 200);
}

function stopTimer() {
  if (state.timerId) {
    clearInterval(state.timerId);
    state.timerId = null;
  }
}

// ===== HUD =====
function updateHPBar() {
  const pct = Math.max(0, Math.min(100, state.hp));
  hpBar.style.width = pct + '%';
  hpText.textContent = Math.round(pct);
  if (pct <= 30) hpBar.classList.add('low'); else hpBar.classList.remove('low');
}

function updateCombo(n) {
  comboEl.textContent = n;
}

function addLesson(shortText) {
  if (!shortText) return;
  const li = document.createElement('li');
  li.textContent = shortText;
  lessonsUl.appendChild(li);
}

// ===== frames de feedback (verde/vermelho) =====
function flashFrames(heroOk) {
  const good = 'frame-green';
  const bad  = 'frame-red';
  if (heroOk) {
    heroFrame.classList.add(good);
    enemyFrame.classList.add(bad);
  } else {
    heroFrame.classList.add(bad);
    enemyFrame.classList.add(good);
  }
  setTimeout(() => {
    heroFrame.classList.remove(good, bad);
    enemyFrame.classList.remove(good, bad);
  }, 300);
}

// ganho incremental por combo: 1, 2, 4, 8, ...
function comboHealAmount(combo) {
  if (combo <= 0) return 0;
  return Math.pow(2, combo - 1);
}

// ===== fluxo principal =====
function spawnVillain() {
  const v = VILLAINS[state.index];
  if (!v) {
    // fim do capítulo
    state.started  = false;
    state.finished = true;
    stopTimer();

    // tempo deste capítulo em segundos
    const sec = Math.floor(state.ms / 1000);

    if (chapterTimeEl) {
      chapterTimeEl.textContent = `${pad2(Math.floor(sec/60))}:${pad2(sec%60)}`;
    }

    // pontos deste capítulo (1 segundo = 1 ponto) * multiplicador do capítulo
    const chapterPoints = sec * CHAPTER_MULTIPLIER;

    if (chapterPointsEl) {
      chapterPointsEl.textContent = chapterPoints;
    }

    // estimativa de pontos totais (total vindos do PHP + pontos deste capítulo)
    if (totalPointsEl) {
      const baseTotal = (typeof window.TOTAL_POINTS === 'number')
        ? window.TOTAL_POINTS
        : Number(window.TOTAL_POINTS || 0);
      totalPointsEl.textContent = baseTotal + chapterPoints;
    }

    // mostra multiplicador na HUD e no box de recompensa
    const multLabel = 'x' + CHAPTER_MULTIPLIER.toFixed(1);
    if (chapterMultiplierEl) chapterMultiplierEl.textContent = multLabel;
    if (runaEl) runaEl.textContent = multLabel;

    // envia para o servidor para gravar nos totais oficiais
    sendScore();

    inputEl.disabled = true;
    feedbackEl.textContent = '✅ Capítulo concluído! Colete sua recompensa.';
    collectBtn.classList.remove('hidden');
    collectBtn.focus();
    return;
  }

  enemyImg.src            = v.img || '';
  enemyImg.alt            = v.name || 'Vilão';
  enemyName.textContent   = v.name || '';
  enemyPhrase.textContent = v.phrase || '';
  promptEl.textContent    = v.key || '—';

  inputEl.value    = '';
  inputEl.disabled = false;
  inputEl.focus();
}

function onCorrect() {
  if (!state.started || state.finished) return;

  state.combo++;
  state.correctCount++;

  // Cura por combo (1, 2, 4, 8, ...)
  state.hp = Math.min(100, state.hp + comboHealAmount(state.combo));
  updateHPBar();
  saveHP();

  flashFrames(true);
  feedbackEl.textContent = '✅ Acertou!';
  updateCombo(state.combo);

  const v = VILLAINS[state.index];
  if (v && v.lessonShort) addLesson(v.lessonShort);

  state.index++;
  spawnVillain();
}

function onMistake() {
  if (!state.started || state.finished) return;

  state.combo = 0;
  updateCombo(0);

  state.hp = Math.max(0, state.hp - 15);
  updateHPBar();
  saveHP();

  flashFrames(false);
  feedbackEl.textContent = '❌ Erro — HP -15';

  if (state.hp <= 0) {
    state.started = false;
    stopTimer();
    inputEl.disabled = true;
    feedbackEl.textContent = '☠️ Você caiu. Reinicie o capítulo ou resete tudo.';

    resetPhaseBtn.classList.remove('hidden');
    resetAllBtn.classList.remove('hidden');
  }
}

// ===== recompensa =====
function showReward() {
  // Dados da recompensa vindos do PHP (se existirem)
  const reward = (window.CAP_DATA && CAP_DATA.reward) || {};

  const name = reward.name || 'Runo da Precisão (Aetha)';
  const img  = reward.img  || 'img/runa_precisao.png';
  const desc = reward.desc ||
    'Aumenta o multiplicador de combos e diminui a perda de HP por erros curtos.\n' +
    'Simboliza o domínio da atenção no Bosque das Palavras Perdidas.';

  if (rewardName) rewardName.textContent = name;
  if (rewardImg) {
    rewardImg.src = img;
    rewardImg.alt = name;
  }
  if (rewardDesc) rewardDesc.textContent = desc;

  // limpar lições e mostrar a recompensa
  if (lessonsUl) lessonsUl.innerHTML = '';

  collectBtn.classList.add('hidden');
  rewardBox.classList.remove('hidden');

  // tempo do capítulo (já calculado)
  if (chapterTimeEl) {
    const sec = Math.floor(state.ms / 1000);
    chapterTimeEl.textContent = `${pad2(Math.floor(sec/60))}:${pad2(sec%60)}`;
  }

  // botão para próximo capítulo (apenas se não for o capítulo 6)
  const currentCap = window.CAP_NUM || 1;
  const nextCap = currentCap + 1;
  
  // Só mostrar próximo capítulo se não for o capítulo 6 (que é o último)
  if (currentCap < 6) {
    let nextBtn = document.getElementById('nextCapBtn');
    if (!nextBtn) {
      nextBtn = document.createElement('a');
      nextBtn.id = 'nextCapBtn';
      nextBtn.className = 'btn btn-small';
      nextBtn.textContent = 'Ir para o Capítulo ' + nextCap;
      
      // Construir URL com parâmetros de liga se necessário
      let nextUrl = 'cap_intro.php?cap=' + nextCap;
      if (window.MODO === 'liga' && window.LIGA_ID) {
        nextUrl += '&modo=liga&liga_id=' + window.LIGA_ID;
      }
      nextBtn.href = nextUrl;
      
      rewardBox.appendChild(document.createElement('br'));
      rewardBox.appendChild(nextBtn);
    } else {
      // Construir URL com parâmetros de liga se necessário
      let nextUrl = 'cap_intro.php?cap=' + nextCap;
      if (window.MODO === 'liga' && window.LIGA_ID) {
        nextUrl += '&modo=liga&liga_id=' + window.LIGA_ID;
      }
      nextBtn.href = nextUrl;
      nextBtn.classList.remove('hidden');
    }
  } else {
    // Capítulo 6 finalizado - mostrar botões apropriados
    if (window.MODO === 'liga' && window.LIGA_ID) {
      // Modo liga: botão para ver ranking da liga
      let ligaBtn = document.getElementById('ligaRankingBtn');
      if (!ligaBtn) {
        ligaBtn = document.createElement('a');
        ligaBtn.id = 'ligaRankingBtn';
        ligaBtn.className = 'btn btn-small';
        ligaBtn.textContent = '🏆 Ver Ranking da Liga';
        ligaBtn.href = 'liga_ranking.php?id=' + window.LIGA_ID;
        ligaBtn.style.marginRight = '1rem';
        
        rewardBox.appendChild(document.createElement('br'));
        rewardBox.appendChild(ligaBtn);
      }
    }
    
    // Botão para voltar ao menu principal sempre
    let menuBtn = document.getElementById('menuBtn');
    if (!menuBtn) {
      menuBtn = document.createElement('a');
      menuBtn.id = 'menuBtn';
      menuBtn.className = 'btn btn-small';
      menuBtn.textContent = '🏠 Menu Principal';
      menuBtn.href = 'trabdev.php';
      
      rewardBox.appendChild(menuBtn);
    }
  }
}

// ===== eventos =====
inputEl.addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  e.preventDefault();

  if (!state.started || state.finished) return;
  const v = VILLAINS[state.index];
  if (!v) return;

  const expected = normalize(v.key);
  const given    = normalize(inputEl.value);

  if (given === expected) onCorrect();
  else onMistake();
});

// resetar só o capítulo (HP volta pra 100, mantém somatório)
resetPhaseBtn?.addEventListener('click', () => {
  var params = 'mode=chapter&cap=' + (window.CAP_NUM || 1);
  if (window.MODO && window.MODO !== 'campanha') {
    params += '&modo=' + window.MODO;
  }
  if (window.LIGA_ID && window.LIGA_ID !== null) {
    params += '&liga_id=' + window.LIGA_ID;
  }
  window.location.href = 'reset_state.php?' + params;
});

// resetar tudo (HP, tempo total, combos etc.)
resetAllBtn?.addEventListener('click', () => {
  var params = 'mode=all&cap=1';
  if (window.MODO && window.MODO !== 'campanha') {
    params += '&modo=' + window.MODO;
  }
  if (window.LIGA_ID && window.LIGA_ID !== null) {
    params += '&liga_id=' + window.LIGA_ID;
  }
  window.location.href = 'reset_state.php?' + params;
});

// coletar recompensa depois de terminar o capítulo
collectBtn?.addEventListener('click', () => {
  showReward();
});

// ===== inicialização =====
window.addEventListener('DOMContentLoaded', () => {
  state.started      = true;
  state.finished     = false;
  state.index        = 0;
  state.combo        = 0;
  state.correctCount = 0;
  state.ms           = 0;

  updateHPBar();
  updateCombo(0);
  if (lessonsUl) lessonsUl.innerHTML = '';
  if (collectBtn) collectBtn.classList.add('hidden');
  if (rewardBox) rewardBox.classList.add('hidden');
  if (resetPhaseBtn) resetPhaseBtn.classList.add('hidden');
  if (resetAllBtn) resetAllBtn.classList.add('hidden');

  // mostra o multiplicador já na HUD
  const multLabel = 'x' + CHAPTER_MULTIPLIER.toFixed(1);
  if (chapterMultiplierEl) chapterMultiplierEl.textContent = multLabel;
  if (runaEl) runaEl.textContent = multLabel;

  // garante que os pontos totais começam coerentes com o PHP
  if (typeof window.TOTAL_POINTS === 'number' && totalPointsEl) {
    totalPointsEl.textContent = window.TOTAL_POINTS;
  }

  startTimer();
  spawnVillain();
});
